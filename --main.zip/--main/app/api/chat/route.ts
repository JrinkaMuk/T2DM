import { type NextRequest, NextResponse } from "next/server"
import { analyzeMedicalConversation, type ChatMessage } from "@/lib/openai-service"

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json()

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json({ error: "Invalid request body. Expected an array of messages." }, { status: 400 })
    }

    // 添加系统提示，引导AI解释医学术语
    const enhancedMessages = [
      {
        role: "system",
        content:
          "你是一个医疗健康助手，专注于将复杂的医学术语和概念转换为普通人能够理解的语言。当用户提到医学术语时，主动解释这些术语。保持友好、专业的语气，避免使用过于专业的术语，如果必须使用，请提供简明的解释。",
      },
      ...(messages as ChatMessage[]),
    ]

    const result = await analyzeMedicalConversation(enhancedMessages as ChatMessage[])

    return result.toDataStreamResponse()
  } catch (error) {
    console.error("Error in chat API route:", error)
    return NextResponse.json({ error: "An error occurred while processing your request." }, { status: 500 })
  }
}
