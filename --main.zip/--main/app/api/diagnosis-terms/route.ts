import { type NextRequest, NextResponse } from "next/server"
import { createClientComponentClient } from "@/lib/supabase"

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const diagnosisId = url.searchParams.get("diagnosisId")

    if (!diagnosisId) {
      return NextResponse.json({ error: "缺少诊断记录ID" }, { status: 400 })
    }

    const supabase = createClientComponentClient()

    // 获取与诊断记录关联的医学术语
    const { data, error } = await supabase
      .from("diagnosis_terms")
      .select(`
        term_id,
        medical_terms (
          id,
          term,
          explanation,
          category
        )
      `)
      .eq("diagnosis_id", diagnosisId)

    if (error) {
      console.error("Error fetching diagnosis terms:", error)
      return NextResponse.json({ error: "获取医学术语失败" }, { status: 500 })
    }

    // 提取医学术语数据
    const terms = data.map((item) => item.medical_terms)

    return NextResponse.json({ terms })
  } catch (error) {
    console.error("Error in diagnosis-terms API route:", error)
    return NextResponse.json({ error: "处理请求失败" }, { status: 500 })
  }
}
