import { type NextRequest, NextResponse } from "next/server"
import { explainDiagnosisRecord } from "@/lib/openai-service"
import { createClientComponentClient } from "@/lib/supabase"

export async function POST(req: NextRequest) {
  try {
    const { diagnosisId } = await req.json()

    if (!diagnosisId) {
      return NextResponse.json({ error: "Invalid request body. Expected diagnosisId." }, { status: 400 })
    }

    // 从Supabase获取诊断记录
    const supabase = createClientComponentClient()
    const { data: diagnosisRecord, error } = await supabase
      .from("diagnosis_records")
      .select("*")
      .eq("id", diagnosisId)
      .single()

    if (error || !diagnosisRecord) {
      console.error("Error fetching diagnosis record:", error)
      return NextResponse.json({ error: "Diagnosis record not found." }, { status: 404 })
    }

    // 转换为OpenAI服务需要的格式
    const formattedRecord = {
      id: diagnosisRecord.id,
      patientId: diagnosisRecord.user_id,
      doctorId: diagnosisRecord.doctor_id || "",
      date: diagnosisRecord.date,
      symptoms: diagnosisRecord.symptoms || "",
      diagnosis: diagnosisRecord.diagnosis || "",
      treatment: diagnosisRecord.treatment || "",
      medications: diagnosisRecord.medications || [],
      followUp: diagnosisRecord.follow_up || "",
      notes: diagnosisRecord.notes || "",
    }

    const result = await explainDiagnosisRecord(formattedRecord)

    return result.toDataStreamResponse()
  } catch (error) {
    console.error("Error in explain-diagnosis API route:", error)
    return NextResponse.json({ error: "An error occurred while processing your request." }, { status: 500 })
  }
}
