import { type NextRequest, NextResponse } from "next/server"
import { explainSingleMedicalTerm } from "@/lib/openai-service"

export async function POST(req: NextRequest) {
  try {
    const { term } = await req.json()

    if (!term || typeof term !== "string") {
      return NextResponse.json({ error: "Invalid request body. Expected a term string." }, { status: 400 })
    }

    const result = await explainSingleMedicalTerm(term)

    return result.toDataStreamResponse()
  } catch (error) {
    console.error("Error in explain-term API route:", error)
    return NextResponse.json({ error: "An error occurred while processing your request." }, { status: 500 })
  }
}
