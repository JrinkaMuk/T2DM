import { type NextRequest, NextResponse } from "next/server"
import { explainMedicalTerms } from "@/lib/openai-service"

export async function POST(req: NextRequest) {
  try {
    const { text } = await req.json()

    if (!text || typeof text !== "string") {
      return NextResponse.json({ error: "Invalid request body. Expected a text string." }, { status: 400 })
    }

    const result = await explainMedicalTerms(text)

    return result.toDataStreamResponse()
  } catch (error) {
    console.error("Error in explain-terms API route:", error)
    return NextResponse.json({ error: "An error occurred while processing your request." }, { status: 500 })
  }
}
