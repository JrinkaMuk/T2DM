import { type NextRequest, NextResponse } from "next/server"
import { createClientComponentClient } from "@/lib/supabase"
import { openai } from "@ai-sdk/openai"
import { generateText } from "ai"

export async function POST(req: NextRequest) {
  try {
    const { userId, title, reportType, diagnosisIds, dateRange } = await req.json()

    if (!userId || !title || !reportType) {
      return NextResponse.json({ error: "缺少必要参数" }, { status: 400 })
    }

    const supabase = createClientComponentClient()

    // 1. 获取用户的诊断记录
    let diagnosisQuery = supabase
      .from("diagnosis_records")
      .select("*")
      .eq("user_id", userId)
      .order("date", { ascending: false })

    // 如果指定了特定的诊断记录ID，则只获取这些记录
    if (diagnosisIds && diagnosisIds.length > 0) {
      diagnosisQuery = diagnosisQuery.in("id", diagnosisIds)
    }

    // 如果指定了日期范围，则按日期过滤
    if (dateRange && dateRange.start && dateRange.end) {
      diagnosisQuery = diagnosisQuery.gte("date", dateRange.start).lte("date", dateRange.end)
    }

    const { data: diagnosisRecords, error: diagnosisError } = await diagnosisQuery

    if (diagnosisError) {
      console.error("Error fetching diagnosis records:", diagnosisError)
      return NextResponse.json({ error: "获取诊断记录失败" }, { status: 500 })
    }

    if (!diagnosisRecords || diagnosisRecords.length === 0) {
      return NextResponse.json({ error: "未找到诊断记录" }, { status: 404 })
    }

    // 2. 获取用户的健康记录
    let healthRecordsQuery = supabase
      .from("health_records")
      .select("*")
      .eq("user_id", userId)
      .order("date", { ascending: false })
      .limit(10)

    // 如果指定了日期范围，则按日期过滤
    if (dateRange && dateRange.start && dateRange.end) {
      healthRecordsQuery = healthRecordsQuery.gte("date", dateRange.start).lte("date", dateRange.end)
    }

    const { data: healthRecords, error: healthError } = await healthRecordsQuery

    if (healthError) {
      console.error("Error fetching health records:", healthError)
    }

    // 3. 获取聊天记录
    let chatHistoryQuery = supabase
      .from("chat_history")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: true })

    // 如果指定了特定的诊断记录ID，则只获取这些记录相关的聊天
    if (diagnosisIds && diagnosisIds.length > 0) {
      chatHistoryQuery = chatHistoryQuery.in("diagnosis_id", diagnosisIds)
    }

    // 如果指定了日期范围，则按日期过滤
    if (dateRange && dateRange.start && dateRange.end) {
      const startDate = new Date(dateRange.start).toISOString()
      const endDate = new Date(dateRange.end).toISOString()
      chatHistoryQuery = chatHistoryQuery.gte("created_at", startDate).lte("created_at", endDate)
    }

    const { data: chatHistory, error: chatError } = await chatHistoryQuery

    if (chatError) {
      console.error("Error fetching chat history:", chatError)
    }

    // 按诊断记录分组聊天记录
    const chatByDiagnosis: Record<string, any[]> = {}

    if (chatHistory && chatHistory.length > 0) {
      chatHistory.forEach((chat) => {
        if (chat.diagnosis_id) {
          if (!chatByDiagnosis[chat.diagnosis_id]) {
            chatByDiagnosis[chat.diagnosis_id] = []
          }
          chatByDiagnosis[chat.diagnosis_id].push(chat)
        }
      })
    }

    // 4. 调用OpenAI API生成健康报告
    const { text: reportContent } = await generateText({
      model: openai("gpt-4-turbo"),
      prompt: `
        请根据以下诊断记录、健康数据和聊天记录，生成一份详细的${reportType}健康报告。
        报告标题: ${title}

        诊断记录:
        ${diagnosisRecords
          .map(
            (record) => `
          日期: ${record.date}
          症状: ${record.symptoms || "无记录"}
          诊断: ${record.diagnosis || "无记录"}
          治疗方案: ${record.treatment || "无记录"}
          药物: ${record.medications ? record.medications.join(", ") : "无记录"}
          复诊安排: ${record.follow_up || "无记录"}
          
          相关聊天记录:
          ${
            chatByDiagnosis[record.id]
              ? chatByDiagnosis[record.id].map((chat) => `[${chat.message_role}]: ${chat.message_content}`).join("\n")
              : "无相关聊天记录"
          }
        `,
          )
          .join("\n\n")}

        ${
          healthRecords && healthRecords.length > 0
            ? `
        健康记录:
        ${healthRecords
          .map(
            (record) => `
          日期: ${record.date}
          饮食: ${record.diet || "无记录"}
          运动: ${record.exercise || "无记录"}
          备注: ${record.notes || "无记录"}
          评估: ${record.evaluation || "无记录"}
        `,
          )
          .join("\n\n")}
        `
            : ""
        }

        请生成一份结构化的健康报告，包括以下部分：
        1. 报告摘要：概述患者的健康状况和主要问题
        2. 诊断历史：总结患者的诊断历史和疾病进展
        3. 用药情况：分析患者的用药情况，包括药物相互作用和潜在风险
        4. 患者关注点：根据聊天记录，总结患者最关心的健康问题
        5. 健康建议：根据患者的情况提供个性化的健康建议
        6. 后续跟进：建议的后续检查和复诊安排

        请使用专业但易于理解的语言，避免过多的医学术语。如果必须使用医学术语，请提供简短的解释。
        这份报告将提供给医生，帮助医生更好地了解患者在就诊间隔期间的健康状况。
      `,
    })

    // 收集所有相关的诊断ID和对话ID
    const diagnosisIdsArray = diagnosisRecords.map((record) => record.id)
    const conversationIds: string[] = []

    if (chatHistory) {
      chatHistory.forEach((chat) => {
        if (chat.conversation_id && !conversationIds.includes(chat.conversation_id)) {
          conversationIds.push(chat.conversation_id)
        }
      })
    }

    // 5. 将报告存入数据库
    const { data: report, error: reportError } = await supabase
      .from("health_reports")
      .insert({
        user_id: userId,
        title,
        content: reportContent,
        report_type: reportType,
        date_range_start: dateRange?.start || null,
        date_range_end: dateRange?.end || null,
        diagnosis_ids: diagnosisIdsArray,
        conversation_ids: conversationIds,
        created_at: new Date().toISOString(), // 确保设置创建时间
      })
      .select()
      .single()

    if (reportError) {
      console.error("Error inserting report:", reportError)
      return NextResponse.json({ error: "保存报告失败" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      reportId: report.id,
      content: reportContent,
    })
  } catch (error) {
    console.error("Error generating report:", error)
    return NextResponse.json({ error: "生成报告失败" }, { status: 500 })
  }
}
