import { type NextRequest, NextResponse } from "next/server"
import { createClientComponentClient } from "@/lib/supabase"
import { openai } from "@ai-sdk/openai"
import { generateText } from "ai"

export async function POST(req: NextRequest) {
  try {
    const { text, date, userId } = await req.json()

    if (!text || !date || !userId) {
      return NextResponse.json({ error: "缺少必要参数" }, { status: 400 })
    }

    const supabase = createClientComponentClient()

    // 1. 调用OpenAI API生成诊断总结
    const { text: diagnosisSummary } = await generateText({
      model: openai("gpt-4-turbo"),
      prompt: `
        请根据以下医患对话，生成一份结构化的诊断总结，包括以下部分：
        1. 症状：患者主诉的症状
        2. 诊断：医生的诊断结果
        3. 治疗方案：医生建议的治疗方法
        4. 药物：医生开具的药物，每种药物单独一行
        5. 复诊安排：医生安排的复诊时间和注意事项

        请使用以下格式：
        症状: [症状描述]
        诊断: [诊断结果]
        治疗方案: [治疗方案]
        药物: [药物列表，每种药物单独一行]
        复诊安排: [复诊安排]

        医患对话内容：
        ${text}
      `,
    })

    // 2. 解析诊断总结
    const symptomsMatch = diagnosisSummary.match(/症状:(.*?)(?=诊断:|$)/s)
    const diagnosisMatch = diagnosisSummary.match(/诊断:(.*?)(?=治疗方案:|$)/s)
    const treatmentMatch = diagnosisSummary.match(/治疗方案:(.*?)(?=药物:|$)/s)
    const medicationsMatch = diagnosisSummary.match(/药物:(.*?)(?=复诊安排:|$)/s)
    const followUpMatch = diagnosisSummary.match(/复诊安排:(.*?)(?=$)/s)

    const symptoms = symptomsMatch ? symptomsMatch[1].trim() : ""
    const diagnosis = diagnosisMatch ? diagnosisMatch[1].trim() : ""
    const treatment = treatmentMatch ? treatmentMatch[1].trim() : ""
    const medicationsText = medicationsMatch ? medicationsMatch[1].trim() : ""
    const followUp = followUpMatch ? followUpMatch[1].trim() : ""

    // 提取药物列表
    const medications = medicationsText
      .split("\n")
      .map((med) => med.trim())
      .filter((med) => med.length > 0)

    // 3. 将诊断记录存入数据库
    const { data: diagnosisRecord, error: insertError } = await supabase
      .from("diagnosis_records")
      .insert({
        user_id: userId,
        date,
        symptoms,
        diagnosis,
        treatment,
        medications,
        follow_up: followUp,
        original_text: text,
        created_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (insertError) {
      console.error("Error inserting diagnosis record:", insertError)
      return NextResponse.json({ error: "保存诊断记录失败" }, { status: 500 })
    }

    // 4. 提取医学术语
    const { text: termsExtraction } = await generateText({
      model: openai("gpt-4-turbo"),
      prompt: `
    请从以下诊断总结中提取所有医学术语，包括疾病名称、症状、药物名称、检查方法等。
    对于每个术语，请提供简短的解释。

    诊断总结：
    ${diagnosisSummary}

    请严格按照以下JSON格式返回结果，确保返回的是有效的JSON数组：
    [
      {"term": "术语1", "explanation": "解释1", "category": "分类1"},
      {"term": "术语2", "explanation": "解释2", "category": "分类2"}
    ]

    不要添加任何额外的文本、注释或说明，只返回JSON数组。
  `,
    })

    // 5. 解析提取的医学术语
    let extractedTerms = []
    try {
      // 尝试清理和解析JSON
      let jsonText = termsExtraction.trim()

      // 查找JSON数组的开始和结束位置
      const startIdx = jsonText.indexOf("[")
      const endIdx = jsonText.lastIndexOf("]")

      if (startIdx !== -1 && endIdx !== -1 && endIdx > startIdx) {
        // 提取JSON数组部分
        jsonText = jsonText.substring(startIdx, endIdx + 1)
        extractedTerms = JSON.parse(jsonText)
      } else {
        // 如果找不到有效的JSON数组，使用正则表达式提取
        console.log("无法找到有效的JSON数组，使用正则表达式提取")
        throw new Error("Invalid JSON format")
      }
    } catch (e) {
      console.error("Error parsing terms JSON:", e)
      // 使用正则表达式提取术语
      const termMatches = termsExtraction.match(/["']term["']\s*:\s*["']([^"']+)["']/g)
      const explanationMatches = termsExtraction.match(/["']explanation["']\s*:\s*["']([^"']+)["']/g)
      const categoryMatches = termsExtraction.match(/["']category["']\s*:\s*["']([^"']+)["']/g)

      if (termMatches && explanationMatches) {
        extractedTerms = termMatches.map((term, index) => {
          // 提取术语名称
          const termValue = term.match(/["']term["']\s*:\s*["']([^"']+)["']/)?.[1] || "未知术语"

          // 提取解释（如果存在）
          const explanationValue =
            explanationMatches[index]?.match(/["']explanation["']\s*:\s*["']([^"']+)["']/)?.[1] || "无解释"

          // 提取分类（如果存在）
          const categoryValue =
            categoryMatches && index < categoryMatches.length
              ? categoryMatches[index].match(/["']category["']\s*:\s*["']([^"']+)["']/)?.[1] || "未分类"
              : "未分类"

          return {
            term: termValue,
            explanation: explanationValue,
            category: categoryValue,
          }
        })
      } else {
        // 如果正则表达式也失败了，手动从文本中提取可能的术语
        console.log("正则表达式提取失败，尝试手动提取术语")

        // 简单地按行分割，并尝试从每行提取术语和解释
        const lines = termsExtraction.split("\n").filter((line) => line.trim().length > 0)

        extractedTerms = lines.map((line) => {
          // 尝试找到术语和解释的分隔符（如冒号）
          const parts = line.split(":").map((part) => part.trim())

          if (parts.length >= 2) {
            return {
              term: parts[0].replace(/[""]/g, ""),
              explanation: parts.slice(1).join(":"),
              category: "未分类",
            }
          } else {
            // 如果无法分割，则整行作为术语
            return {
              term: line.replace(/[""]/g, ""),
              explanation: "无解释",
              category: "未分类",
            }
          }
        })
      }
    }

    // 6. 存储提取的医学术语
    for (const termData of extractedTerms) {
      // 检查术语是否已存在
      const { data: existingTerm, error: termQueryError } = await supabase
        .from("medical_terms")
        .select("id")
        .eq("term", termData.term)
        .maybeSingle()

      if (termQueryError) {
        console.error("Error querying medical term:", termQueryError)
        continue
      }

      let termId

      if (existingTerm) {
        termId = existingTerm.id
      } else {
        // 插入新术语
        const { data: newTerm, error: insertTermError } = await supabase
          .from("medical_terms")
          .insert({
            term: termData.term,
            explanation: termData.explanation,
            category: termData.category,
          })
          .select("id")
          .single()

        if (insertTermError) {
          console.error("Error inserting medical term:", insertTermError)
          continue
        }

        termId = newTerm.id
      }

      // 创建诊断记录和医学术语的关联
      const { error: insertRelationError } = await supabase.from("diagnosis_terms").insert({
        diagnosis_id: diagnosisRecord.id,
        term_id: termId,
      })

      if (insertRelationError) {
        console.error("Error inserting diagnosis term relation:", insertRelationError)
      }
    }

    return NextResponse.json({
      success: true,
      diagnosisId: diagnosisRecord.id,
      summary: diagnosisSummary,
      extractedTerms: extractedTerms.map((t) => t.term),
    })
  } catch (error) {
    console.error("Error processing diagnosis upload:", error)
    return NextResponse.json({ error: "处理诊断上传失败" }, { status: 500 })
  }
}
