"use client"

import type React from "react"

import { useState, useRef, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import type { Message } from "@/types/health"
import { createClientComponentClient } from "@/lib/supabase"
import {
  Send,
  Bot,
  User,
  Loader2,
  FileText,
  ChevronDown,
  ChevronUp,
  Search,
  HelpCircle,
  Calendar,
  PanelRightOpen,
  PanelRightClose,
  Info,
  Menu,
  X,
  Plus,
} from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useChat } from "@/contexts/chat-context"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { UploadDialog } from "@/components/upload-dialog"
import { clientDataService } from "@/lib/data-service"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function ChatPage() {
  const { user } = useAuth()
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [diagnosisRecords, setDiagnosisRecords] = useState<any[]>([])
  const [isExplainingDiagnosis, setIsExplainingDiagnosis] = useState(false)
  const [expandedDiagnosis, setExpandedDiagnosis] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [showSidebar, setShowSidebar] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const { toast } = useToast()
  const [isLoadingTerms, setIsLoadingTerms] = useState(false)
  const [isLoadingRecords, setIsLoadingRecords] = useState(true)
  const [refreshTrigger, setRefreshTrigger] = useState(0)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  // 检测移动设备
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  // 使用聊天上下文
  const { currentSession, setCurrentSession, getSession, updateSession, getAllSessions, isLoadingSessions } = useChat()

  // 从会话中获取状态
  const session = currentSession
    ? getSession(currentSession)
    : { messages: [], selectedDiagnosisId: null, diagnosisTerms: [] }
  const messages = session.messages
  const selectedDiagnosisId = session.selectedDiagnosisId
  const diagnosisTerms = session.diagnosisTerms

  // 刷新诊断记录 - 使用useCallback避免不必要的重新渲染
  const refreshDiagnosisRecords = useCallback(() => {
    setRefreshTrigger((prev) => prev + 1)
  }, [])

  // 获取用户的诊断记录
  useEffect(() => {
    async function fetchDiagnosisRecords() {
      if (user) {
        setIsLoadingRecords(true)
        try {
          const supabase = createClientComponentClient()
          const { data, error } = await supabase
            .from("diagnosis_records")
            .select("*")
            .eq("user_id", user.id)
            .order("date", { ascending: false })

          if (error) {
            throw error
          }

          setDiagnosisRecords(data || [])

          // 如果有诊断记录但没有选择的诊断ID，默认选择最新的一条
          if (data && data.length > 0 && !currentSession && !isLoadingSessions) {
            const newSessionId = data[0].id
            setCurrentSession(newSessionId)
            updateSession(newSessionId, { selectedDiagnosisId: data[0].id })
          }
        } catch (error) {
          console.error("Error fetching diagnosis records:", error)
          toast({
            title: "获取诊断记录失败",
            description: "请稍后再试",
            variant: "destructive",
          })
        } finally {
          setIsLoadingRecords(false)
        }
      }
    }

    fetchDiagnosisRecords()
  }, [user, toast, currentSession, setCurrentSession, updateSession, refreshTrigger, isLoadingSessions])

  // 当选择的诊断记录改变时，自动解释
  useEffect(() => {
    if (selectedDiagnosisId && (!messages || messages.length === 0) && !isLoadingSessions) {
      explainDiagnosis(selectedDiagnosisId)
    }
  }, [selectedDiagnosisId, messages, isLoadingSessions])

  // 当选择的诊断记录改变时，获取关联的医学术语
  useEffect(() => {
    if (selectedDiagnosisId && (!diagnosisTerms || diagnosisTerms.length === 0) && !isLoadingSessions) {
      fetchDiagnosisTerms(selectedDiagnosisId)
    }
  }, [selectedDiagnosisId, diagnosisTerms, isLoadingSessions])

  // 自动滚动到最新消息
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // 获取与诊断记录关联的医学术语
  const fetchDiagnosisTerms = async (diagnosisId: string) => {
    if (!currentSession) return

    setIsLoadingTerms(true)
    try {
      const response = await fetch(`/api/diagnosis-terms?diagnosisId=${diagnosisId}`)
      if (!response.ok) {
        throw new Error("Failed to fetch diagnosis terms")
      }
      const data = await response.json()

      updateSession(currentSession, { diagnosisTerms: data.terms || [] })
    } catch (error) {
      console.error("Error fetching diagnosis terms:", error)
      toast({
        title: "获取医学术语失败",
        description: "请稍后再试",
        variant: "destructive",
      })
    } finally {
      setIsLoadingTerms(false)
    }
  }

  // 解释诊断记录
  const explainDiagnosis = async (diagnosisId: string) => {
    if (!currentSession) {
      setCurrentSession(diagnosisId)
    }

    setIsExplainingDiagnosis(true)

    // 添加系统消息，告知用户正在解释诊断
    const systemMessage: Message = {
      id: Date.now().toString(),
      role: "assistant",
      content: "我正在分析您的诊断记录，稍后将为您提供易于理解的解释...",
      timestamp: new Date().toISOString(),
    }

    const existingMessages = currentSession ? getSession(currentSession).messages : []
    if (existingMessages.length === 0) {
      updateSession(currentSession || diagnosisId, {
        messages: [systemMessage],
        selectedDiagnosisId: diagnosisId,
      })
    }

    try {
      const response = await fetch("/api/explain-diagnosis", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ diagnosisId }),
      })

      if (!response.ok) {
        throw new Error("Failed to explain diagnosis")
      }

      const reader = response.body?.getReader()
      if (!reader) throw new Error("Response body is null")

      const decoder = new TextDecoder()
      let explanation = ""

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        const chunk = decoder.decode(value, { stream: true })
        explanation += chunk

        // 更新消息
        const assistantMessage: Message = {
          id: Date.now().toString(),
          role: "assistant",
          content: explanation,
          timestamp: new Date().toISOString(),
        }

        updateSession(currentSession || diagnosisId, {
          messages: [assistantMessage],
          selectedDiagnosisId: diagnosisId,
        })
      }

      // 保存解释到聊天历史
      if (user && explanation) {
        const finalMessage = {
          id: Date.now().toString(),
          role: "assistant" as const,
          content: explanation,
          timestamp: new Date().toISOString(),
        }

        await clientDataService.saveChatHistory(
          user.id,
          null,
          diagnosisId,
          finalMessage,
          true, // 这是一个分析消息
        )

        // 添加引导消息
        const guidanceMessage: Message = {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content:
            "您可以随时询问我关于您的诊断记录的任何问题，或者分享您的健康状况。我会尽力帮助您理解医学术语，并记录您的健康信息，以便在您下次就诊时提供给医生参考。您今天感觉如何？有任何不适或者想要分享的健康信息吗？",
          timestamp: new Date().toISOString(),
        }

        const currentMessages = currentSession ? getSession(currentSession).messages : []
        if (currentMessages.length <= 1) {
          // 只有系统消息或没有消息
          updateSession(currentSession || diagnosisId, {
            messages: [finalMessage, guidanceMessage],
            selectedDiagnosisId: diagnosisId,
          })
        }

        await clientDataService.saveChatHistory(user.id, null, diagnosisId, guidanceMessage, false)
      }
    } catch (error) {
      console.error("Error explaining diagnosis:", error)
      toast({
        title: "解释诊断记录失败",
        description: "请稍后再试",
        variant: "destructive",
      })

      // 添加错误消息
      const errorMessage: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: "抱歉，我无法解释这份诊断记录。请稍后再试。",
        timestamp: new Date().toISOString(),
      }

      updateSession(currentSession || diagnosisId, {
        messages: [errorMessage],
        selectedDiagnosisId: diagnosisId,
      })

      // 保存错误消息到聊天历史
      if (user) {
        await clientDataService.saveChatHistory(user.id, null, diagnosisId, errorMessage, false)
      }
    } finally {
      setIsExplainingDiagnosis(false)
    }
  }

  // 解释单个医学术语
  const explainMedicalTerm = async (term: string) => {
    if (!currentSession || !user) return

    // 添加用户消息
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: `请解释"${term}"这个医学术语`,
      timestamp: new Date().toISOString(),
    }

    updateSession(currentSession, {
      messages: [...messages, userMessage],
    })

    // 保存用户消息到聊天历史
    await clientDataService.saveChatHistory(user.id, null, selectedDiagnosisId, userMessage, false)

    setIsLoading(true)

    try {
      const response = await fetch("/api/explain-term", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ term }),
      })

      if (!response.ok) {
        throw new Error("Failed to explain medical term")
      }

      const reader = response.body?.getReader()
      if (!reader) throw new Error("Response body is null")

      const decoder = new TextDecoder()
      let explanation = ""

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        const chunk = decoder.decode(value, { stream: true })
        explanation += chunk

        // 更新消息
        const assistantMessage: Message = {
          id: Date.now().toString(),
          role: "assistant",
          content: explanation,
          timestamp: new Date().toISOString(),
        }

        updateSession(currentSession, {
          messages: [...messages, userMessage, assistantMessage],
        })
      }

      // 保存最终回复到聊天历史
      const finalMessage = {
        id: Date.now().toString(),
        role: "assistant" as const,
        content: explanation,
        timestamp: new Date().toISOString(),
      }

      await clientDataService.saveChatHistory(user.id, null, selectedDiagnosisId, finalMessage, false)
    } catch (error) {
      console.error("Error explaining medical term:", error)
      toast({
        title: "解释医学术语失败",
        description: "请稍后再试",
        variant: "destructive",
      })

      // 添加错误消息
      const errorMessage: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: `抱歉，我无法解释"${term}"这个术语。请稍后再试。`,
        timestamp: new Date().toISOString(),
      }

      updateSession(currentSession, {
        messages: [...messages, userMessage, errorMessage],
      })

      // 保存错误消息到聊天历史
      await clientDataService.saveChatHistory(user.id, null, selectedDiagnosisId, errorMessage, false)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!input.trim() || !currentSession || !user) return

    // 添加用户消息
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date().toISOString(),
    }

    updateSession(currentSession, {
      messages: [...messages, userMessage],
    })

    // 保存用户消息到聊天历史
    await clientDataService.saveChatHistory(user.id, null, selectedDiagnosisId, userMessage, false)

    setInput("")
    setIsLoading(true)

    try {
      // 构建完整的对话历史，包括系统提示
      const fullMessages = [
        {
          role: "system",
          content:
            "你是一个医疗健康助手，专注于将复杂的医学术语和概念转换为普通人能够理解的语言。当用户提到医学术语时，主动解释这些术语。保持友好、专业的语气，避免使用过于专业的术语，如果必须使用，请提供简明的解释。同时，你需要积极引导用户分享他们的健康状况，包括症状、用药情况、饮食习惯、运动情况等，以便收集完整的健康信息。这些信息将用于生成健康报告，帮助医生更好地了解患者的情况。",
        },
        ...messages.map((m) => ({
          role: m.role,
          content: m.content,
        })),
        {
          role: userMessage.role,
          content: userMessage.content,
        },
      ]

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: fullMessages,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to get chat response")
      }

      const reader = response.body?.getReader()
      if (!reader) throw new Error("Response body is null")

      const decoder = new TextDecoder()
      let assistantResponse = ""

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        const chunk = decoder.decode(value, { stream: true })
        assistantResponse += chunk

        // 更新消息
        const assistantMessage: Message = {
          id: Date.now().toString(),
          role: "assistant",
          content: assistantResponse,
          timestamp: new Date().toISOString(),
        }

        updateSession(currentSession, {
          messages: [...messages, userMessage, assistantMessage],
        })
      }

      // 保存最终回复到聊天历史
      const finalMessage = {
        id: Date.now().toString(),
        role: "assistant" as const,
        content: assistantResponse,
        timestamp: new Date().toISOString(),
      }

      await clientDataService.saveChatHistory(user.id, null, selectedDiagnosisId, finalMessage, false)
    } catch (error) {
      console.error("Error sending message:", error)
      toast({
        title: "发送消息失败",
        description: "请稍后再试",
        variant: "destructive",
      })

      // 添加错误消息
      const errorMessage: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: "抱歉，我无法回答您的问题。请稍后再试。",
        timestamp: new Date().toISOString(),
      }

      updateSession(currentSession, {
        messages: [...messages, userMessage, errorMessage],
      })

      // 保存错误消息到聊天历史
      await clientDataService.saveChatHistory(user.id, null, selectedDiagnosisId, errorMessage, false)
    } finally {
      setIsLoading(false)
    }
  }

  // 切换诊断记录的展开/折叠状态
  const toggleDiagnosisExpand = (diagnosisId: string) => {
    if (expandedDiagnosis === diagnosisId) {
      setExpandedDiagnosis(null)
    } else {
      setExpandedDiagnosis(diagnosisId)
    }
  }

  // 选择诊断记录
  const selectDiagnosis = (diagnosisId: string) => {
    setCurrentSession(diagnosisId)
    updateSession(diagnosisId, { selectedDiagnosisId: diagnosisId })
    // 在移动端选择诊断后关闭侧边栏
    setIsMobileMenuOpen(false)
  }

  // 过滤诊断记录
  const filteredDiagnosisRecords = diagnosisRecords.filter(
    (record) =>
      (record.diagnosis && record.diagnosis.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (record.date && record.date.includes(searchTerm)),
  )

  // 过滤医学术语
  const filteredMedicalTerms = diagnosisTerms.filter((term) =>
    term.term.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // 格式化时间
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  // 获取所有会话
  const allSessions = getAllSessions()

  // 获取当前选中的诊断记录
  const currentDiagnosis = diagnosisRecords.find((record) => record.id === selectedDiagnosisId)

  // 显示加载状态
  if (isLoadingSessions) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-180px)]">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-teal-500 mx-auto mb-4" />
          <p className="text-lg font-medium">正在加载您的聊天记录...</p>
          <p className="text-sm text-muted-foreground mt-2">请稍候，我们正在从服务器获取您的对话历史</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-2 sm:px-4 max-w-6xl">
      {/* 移动端顶部导航栏 */}
      <div className="flex justify-between items-center mb-4 md:hidden">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">健康对话</h1>
          {currentDiagnosis && (
            <div className="flex items-center mt-1">
              <Calendar className="h-3 w-3 text-muted-foreground mr-1" />
              <span className="text-xs text-muted-foreground">{currentDiagnosis.date}</span>
            </div>
          )}
        </div>
        <div className="flex gap-2">
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="h-9 w-9">
                <Menu className="h-4 w-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[85%] sm:w-[350px] p-0">
              <div className="flex flex-col h-full">
                <div className="flex justify-between items-center p-4 border-b">
                  <h2 className="font-semibold">诊断记录与话题</h2>
                  <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(false)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <Tabs defaultValue="records" className="flex-1 flex flex-col">
                  <TabsList className="mx-4 mt-2 grid w-auto grid-cols-2">
                    <TabsTrigger value="records">诊断记录</TabsTrigger>
                    <TabsTrigger value="terms">相关话题</TabsTrigger>
                  </TabsList>
                  <TabsContent value="records" className="flex-1 overflow-hidden p-4">
                    <div className="relative mb-4">
                      <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        placeholder="搜索诊断记录..."
                        className="pl-8"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="text-sm font-medium">您的诊断记录</h3>
                      <UploadDialog
                        buttonText="上传"
                        onUploadSuccess={refreshDiagnosisRecords}
                        className="h-8 text-xs"
                      />
                    </div>
                    <ScrollArea className="h-[calc(100vh-250px)]">
                      {isLoadingRecords ? (
                        <div className="flex justify-center py-8">
                          <Loader2 className="h-8 w-8 animate-spin text-teal-500" />
                        </div>
                      ) : filteredDiagnosisRecords.length > 0 ? (
                        <div className="space-y-3">
                          {filteredDiagnosisRecords.map((record) => (
                            <div
                              key={record.id}
                              className={`border rounded-lg p-3 transition-all ${
                                currentSession === record.id
                                  ? "border-teal-500 bg-teal-50 dark:bg-teal-900/20 dark:border-teal-600"
                                  : "hover:border-teal-200 hover:bg-gray-50 dark:hover:bg-gray-800/50 dark:border-gray-700"
                              }`}
                            >
                              <div
                                className="flex justify-between items-center cursor-pointer"
                                onClick={() => toggleDiagnosisExpand(record.id)}
                              >
                                <div className="flex items-center">
                                  <div className="rounded-full bg-teal-100 dark:bg-teal-800/50 p-1.5 mr-2">
                                    <Calendar className="h-3 w-3 text-teal-500 dark:text-teal-400" />
                                  </div>
                                  <div>
                                    <h3 className="font-medium text-sm">{record.date}</h3>
                                    <p className="text-xs text-muted-foreground truncate max-w-[180px]">
                                      {record.diagnosis}
                                    </p>
                                  </div>
                                </div>
                                {expandedDiagnosis === record.id ? (
                                  <ChevronUp className="h-4 w-4 text-teal-500 dark:text-teal-400" />
                                ) : (
                                  <ChevronDown className="h-4 w-4" />
                                )}
                              </div>

                              {expandedDiagnosis === record.id && (
                                <div className="mt-3 space-y-2 text-xs border-t pt-2 dark:border-gray-700">
                                  <div className="grid grid-cols-[80px_1fr] gap-1">
                                    <span className="font-medium text-muted-foreground">症状:</span>
                                    <span>{record.symptoms}</span>
                                  </div>
                                  <div className="grid grid-cols-[80px_1fr] gap-1">
                                    <span className="font-medium text-muted-foreground">诊断:</span>
                                    <span>{record.diagnosis}</span>
                                  </div>
                                  <div className="grid grid-cols-[80px_1fr] gap-1">
                                    <span className="font-medium text-muted-foreground">治疗方案:</span>
                                    <span>{record.treatment}</span>
                                  </div>
                                  <div className="grid grid-cols-[80px_1fr] gap-1">
                                    <span className="font-medium text-muted-foreground">药物:</span>
                                    <div className="flex flex-wrap gap-1">
                                      {record.medications &&
                                        record.medications.map((med: string) => (
                                          <Badge
                                            key={med}
                                            variant="secondary"
                                            className="bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 text-[10px] py-0"
                                          >
                                            {med}
                                          </Badge>
                                        ))}
                                    </div>
                                  </div>
                                  <div className="grid grid-cols-[80px_1fr] gap-1">
                                    <span className="font-medium text-muted-foreground">复诊安排:</span>
                                    <span>{record.follow_up}</span>
                                  </div>
                                  <Button
                                    className="mt-2 w-full bg-teal-500 hover:bg-teal-600 h-8 text-xs dark:bg-teal-600 dark:hover:bg-teal-700"
                                    onClick={(e) => {
                                      e.stopPropagation()
                                      selectDiagnosis(record.id)
                                    }}
                                  >
                                    {currentSession === record.id ? "已选择此诊断" : "解释这份诊断"}
                                  </Button>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                          <p className="text-sm">没有找到诊断记录</p>
                          <UploadDialog
                            buttonText="上传诊断记录"
                            onUploadSuccess={refreshDiagnosisRecords}
                            className="mt-4"
                          />
                        </div>
                      )}
                    </ScrollArea>
                  </TabsContent>
                  <TabsContent value="terms" className="flex-1 overflow-hidden p-4">
                    <div className="relative mb-4">
                      <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        placeholder="搜索话题..."
                        className="pl-8"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="text-sm font-medium">相关医学话题</h3>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <HelpCircle className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="text-xs">点击任意话题获取详细解释</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    <ScrollArea className="h-[calc(100vh-250px)]">
                      {isLoadingTerms ? (
                        <div className="flex justify-center py-8">
                          <Loader2 className="h-8 w-8 animate-spin text-teal-500" />
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 gap-3">
                          {filteredMedicalTerms.length > 0 ? (
                            filteredMedicalTerms.map((term) => (
                              <Button
                                key={term.id}
                                variant="outline"
                                className="justify-start h-auto py-2 px-3 text-sm w-full border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800"
                                onClick={() => {
                                  explainMedicalTerm(term.term)
                                  setIsMobileMenuOpen(false)
                                }}
                              >
                                <div className="flex items-center">
                                  <Info className="h-4 w-4 text-blue-500 dark:text-blue-400 mr-2 flex-shrink-0" />
                                  <span className="truncate">{term.term}</span>
                                </div>
                              </Button>
                            ))
                          ) : (
                            <div className="text-center py-8">
                              <Info className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                              <p className="text-sm">
                                {selectedDiagnosisId ? "此诊断记录中没有找到相关话题" : "没有找到匹配的话题"}
                              </p>
                              <p className="text-xs text-muted-foreground mt-2">
                                您可以直接在对话框中输入问题，询问任何健康相关的话题
                              </p>
                            </div>
                          )}
                        </div>
                      )}
                    </ScrollArea>
                  </TabsContent>
                </Tabs>
              </div>
            </SheetContent>
          </Sheet>
          <UploadDialog buttonText="上传" onUploadSuccess={refreshDiagnosisRecords} className="h-9 px-3 text-xs" />
        </div>
      </div>

      {/* 桌面端顶部导航栏 */}
      <div className="hidden md:flex justify-between items-center mb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold mb-2 text-gray-900 dark:text-white">健康对话</h1>
          <p className="text-sm sm:text-base text-muted-foreground dark:text-gray-400">
            与AI助手交流，解释医学术语，获取健康建议，记录您的健康状况
          </p>
        </div>
        <div className="flex gap-2">
          <UploadDialog onUploadSuccess={refreshDiagnosisRecords} />
          <Button
            variant="outline"
            size="sm"
            className="md:hidden dark:border-gray-700 dark:text-gray-300"
            onClick={() => setShowSidebar(!showSidebar)}
          >
            {showSidebar ? "隐藏侧边栏" : "显示侧边栏"}
          </Button>
        </div>
      </div>

      <div className="relative flex flex-col md:flex-row h-[calc(100vh-180px)] min-h-[500px] gap-4">
        {/* 主聊天区域 - 始终显示 */}
        <div className="flex-1 flex flex-col order-2 md:order-1">
          {/* 聊天卡片 */}
          <Card className="flex-1 flex flex-col shadow-md overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-teal-500 to-teal-600 text-white border-b pb-3 flex-shrink-0 p-3 sm:p-4">
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center text-base sm:text-lg text-white">
                  <Bot className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
                  健康助手对话
                  {selectedDiagnosisId && diagnosisRecords.length > 0 && (
                    <Badge className="ml-2 bg-white/20 text-white text-xs">
                      {diagnosisRecords.find((r) => r.id === selectedDiagnosisId)?.date || "诊断记录"}
                    </Badge>
                  )}
                </CardTitle>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-white hover:bg-teal-600 h-8 w-8 hidden md:flex"
                  onClick={() => setShowSidebar(!showSidebar)}
                >
                  {showSidebar ? <PanelRightClose className="h-4 w-4" /> : <PanelRightOpen className="h-4 w-4" />}
                </Button>
              </div>
              <CardDescription className="text-teal-100 text-xs sm:text-sm">
                我可以帮您解释医学术语，回答健康问题，记录您的健康状况
              </CardDescription>
            </CardHeader>

            <CardContent className="flex-1 overflow-y-auto p-3 sm:p-4 bg-gray-50 dark:bg-gray-900/20 min-h-[300px] dark:text-gray-200">
              <div className="space-y-4">
                {messages.length === 0 && !isExplainingDiagnosis && (
                  <div className="text-center py-8">
                    <Bot className="h-10 w-10 sm:h-12 sm:w-12 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm">选择一份诊断记录开始解释，或直接发送消息咨询</p>
                    <p className="text-xs text-muted-foreground mt-2">
                      您的健康对话将被记录，用于生成健康报告，帮助医生更好地了解您的情况
                    </p>
                  </div>
                )}

                {messages.map((message, index) => (
                  <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`flex items-start gap-2 max-w-[90%] sm:max-w-[80%] ${
                        message.role === "user" ? "flex-row-reverse" : ""
                      }`}
                    >
                      <div
                        className={`rounded-full p-1.5 sm:p-2 ${
                          message.role === "user" ? "bg-teal-500 text-white" : "bg-white dark:bg-gray-800 shadow-sm"
                        }`}
                      >
                        {message.role === "user" ? (
                          <User className="h-3 w-3 sm:h-4 sm:w-4" />
                        ) : (
                          <Bot className="h-3 w-3 sm:h-4 sm:w-4 text-teal-500 dark:text-teal-400" />
                        )}
                      </div>
                      <div className="flex flex-col">
                        <div
                          className={`rounded-lg p-2 sm:p-3 text-sm sm:text-base ${
                            message.role === "user"
                              ? "bg-teal-500 text-white"
                              : "bg-white dark:bg-gray-800 shadow-sm text-gray-800 dark:text-white"
                          }`}
                        >
                          <div
                            className="prose-sm dark:prose-invert max-w-none"
                            dangerouslySetInnerHTML={{ __html: message.content }}
                          />
                        </div>
                        <div
                          className={`text-[10px] sm:text-xs text-gray-500 dark:text-gray-400 mt-1 ${message.role === "user" ? "text-right" : ""}`}
                        >
                          {formatTime(message.timestamp)}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}

                {isExplainingDiagnosis && (
                  <div className="flex justify-start">
                    <div className="flex items-start gap-2 max-w-[90%] sm:max-w-[80%]">
                      <div className="rounded-full p-1.5 sm:p-2 bg-white dark:bg-gray-800 shadow-sm">
                        <Bot className="h-3 w-3 sm:h-4 sm:w-4 text-teal-500 dark:text-teal-400" />
                      </div>
                      <div className="rounded-lg p-2 sm:p-3 bg-white dark:bg-gray-800 shadow-sm flex items-center text-sm sm:text-base text-gray-800 dark:text-white">
                        <Loader2 className="h-3 w-3 sm:h-4 sm:w-4 animate-spin mr-2 text-teal-500 dark:text-teal-400" />
                        正在分析诊断记录...
                      </div>
                    </div>
                  </div>
                )}

                {isLoading && (
                  <div className="flex justify-start">
                    <div className="flex items-start gap-2 max-w-[90%] sm:max-w-[80%]">
                      <div className="rounded-full p-1.5 sm:p-2 bg-white dark:bg-gray-800 shadow-sm">
                        <Bot className="h-3 w-3 sm:h-4 sm:w-4 text-teal-500 dark:text-teal-400" />
                      </div>
                      <div className="rounded-lg p-2 sm:p-3 bg-white dark:bg-gray-800 shadow-sm flex items-center text-sm sm:text-base text-gray-800 dark:text-white">
                        <Loader2 className="h-3 w-3 sm:h-4 sm:w-4 animate-spin mr-2 text-teal-500 dark:text-teal-400" />
                        正在思考...
                      </div>
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>
            </CardContent>

            <CardFooter className="border-t p-2 sm:p-3 bg-white dark:bg-gray-900 dark:border-gray-800 flex-shrink-0">
              <form onSubmit={handleSendMessage} className="flex w-full gap-2">
                <Input
                  placeholder="输入您的问题或健康状况..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  disabled={isLoading || isExplainingDiagnosis || !currentSession}
                  className="border-teal-200 focus-visible:ring-teal-500 text-sm sm:text-base h-10 sm:h-12 dark:bg-gray-800 dark:border-gray-700"
                />
                <Button
                  type="submit"
                  size="icon"
                  disabled={isLoading || isExplainingDiagnosis || !input.trim() || !currentSession}
                  className="bg-teal-500 hover:bg-teal-600 h-10 w-10 sm:h-12 sm:w-12 dark:bg-teal-600 dark:hover:bg-teal-700"
                >
                  <Send className="h-4 w-4 sm:h-5 sm:w-5" />
                </Button>
              </form>
            </CardFooter>
          </Card>
        </div>

        {/* 桌面端侧边栏 */}
        <div
          className={`${
            showSidebar ? "md:block" : "hidden"
          } hidden md:w-72 lg:w-80 flex flex-col space-y-4 order-1 md:order-2`}
        >
          <Tabs defaultValue="records" className="h-full flex flex-col">
            <TabsList className="grid w-full grid-cols-2 bg-gray-100 dark:bg-gray-800 flex-shrink-0">
              <TabsTrigger
                value="records"
                className="text-xs sm:text-sm data-[state=active]:bg-white dark:data-[state=active]:bg-gray-700"
              >
                诊断记录
              </TabsTrigger>
              <TabsTrigger
                value="terms"
                className="text-xs sm:text-sm data-[state=active]:bg-white dark:data-[state=active]:bg-gray-700"
              >
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span className="flex items-center">
                        相关话题
                        <HelpCircle className="ml-1 h-3 w-3 text-muted-foreground" />
                      </span>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs">点击下方任意话题获取详细解释</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="records" className="flex-1 overflow-hidden mt-2">
              <Card className="h-full flex flex-col border-teal-200 dark:border-teal-800/30 shadow-sm">
                <CardHeader className="bg-teal-50 dark:bg-teal-900/20 border-b border-teal-100 dark:border-teal-800/30 pb-2 flex-shrink-0 p-3">
                  <div className="flex justify-between items-center">
                    <CardTitle className="flex items-center text-sm sm:text-base">
                      <FileText className="h-3 w-3 sm:h-4 sm:w-4 text-teal-500 dark:text-teal-400 mr-1 sm:mr-2" />
                      您的诊断记录
                    </CardTitle>
                    <div className="relative w-24 sm:w-32">
                      <Search className="absolute left-2 top-2 h-3 w-3 text-muted-foreground" />
                      <Input
                        placeholder="搜索..."
                        className="pl-7 h-7 text-xs dark:bg-gray-800 dark:border-gray-700"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                  </div>
                  <CardDescription className="text-xs">选择一份诊断记录获取解释</CardDescription>
                </CardHeader>

                <CardContent className="p-0 flex-1 overflow-hidden">
                  <ScrollArea className="h-[calc(100%-40px)] p-2 sm:p-3">
                    {isLoadingRecords ? (
                      <div className="flex items-center justify-center h-full">
                        <Loader2 className="h-8 w-8 animate-spin text-teal-500" />
                      </div>
                    ) : filteredDiagnosisRecords.length > 0 ? (
                      <div className="space-y-2 sm:space-y-3">
                        {filteredDiagnosisRecords.map((record) => (
                          <div
                            key={record.id}
                            className={`border rounded-lg p-2 sm:p-3 transition-all ${
                              currentSession === record.id
                                ? "border-teal-500 bg-teal-50 dark:bg-teal-900/20 dark:border-teal-600"
                                : "hover:border-teal-200 hover:bg-gray-50 dark:hover:bg-gray-800/50 dark:border-gray-700"
                            }`}
                          >
                            <div
                              className="flex justify-between items-center cursor-pointer"
                              onClick={() => toggleDiagnosisExpand(record.id)}
                            >
                              <div className="flex items-center">
                                <div className="rounded-full bg-teal-100 dark:bg-teal-800/50 p-1 sm:p-1.5 mr-1.5 sm:mr-2">
                                  <Calendar className="h-2.5 w-2.5 sm:h-3 sm:w-3 text-teal-500 dark:text-teal-400" />
                                </div>
                                <div>
                                  <div className="flex items-center">
                                    <h3 className="font-medium text-xs sm:text-sm">{record.date}</h3>
                                    <Badge
                                      variant="outline"
                                      className="ml-1 sm:ml-2 text-[10px] scale-75 origin-left dark:border-gray-600"
                                    >
                                      {record.medications && record.medications.length > 0
                                        ? `${record.medications.length}种药物`
                                        : "无药物"}
                                    </Badge>
                                  </div>
                                  <p className="text-[10px] sm:text-xs text-muted-foreground truncate max-w-[150px] sm:max-w-[180px]">
                                    {record.diagnosis}
                                  </p>
                                </div>
                              </div>
                              {expandedDiagnosis === record.id ? (
                                <ChevronUp className="h-3 w-3 sm:h-4 sm:w-4 text-teal-500 dark:text-teal-400" />
                              ) : (
                                <ChevronDown className="h-3 w-3 sm:h-4 sm:w-4" />
                              )}
                            </div>

                            {expandedDiagnosis === record.id && (
                              <div className="mt-2 sm:mt-3 space-y-1 sm:space-y-2 text-[10px] sm:text-xs border-t pt-2 dark:border-gray-700">
                                <div className="grid grid-cols-[70px_1fr] sm:grid-cols-[80px_1fr] gap-1">
                                  <span className="font-medium text-muted-foreground">症状:</span>
                                  <span>{record.symptoms}</span>
                                </div>
                                <div className="grid grid-cols-[70px_1fr] sm:grid-cols-[80px_1fr] gap-1">
                                  <span className="font-medium text-muted-foreground">诊断:</span>
                                  <span>{record.diagnosis}</span>
                                </div>
                                <div className="grid grid-cols-[70px_1fr] sm:grid-cols-[80px_1fr] gap-1">
                                  <span className="font-medium text-muted-foreground">治疗方案:</span>
                                  <span>{record.treatment}</span>
                                </div>
                                <div className="grid grid-cols-[70px_1fr] sm:grid-cols-[80px_1fr] gap-1">
                                  <span className="font-medium text-muted-foreground">药物:</span>
                                  <div className="flex flex-wrap gap-1">
                                    {record.medications &&
                                      record.medications.map((med: string) => (
                                        <Badge
                                          key={med}
                                          variant="secondary"
                                          className="bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 text-[8px] sm:text-[10px] py-0"
                                        >
                                          {med}
                                        </Badge>
                                      ))}
                                  </div>
                                </div>
                                <div className="grid grid-cols-[70px_1fr] sm:grid-cols-[80px_1fr] gap-1">
                                  <span className="font-medium text-muted-foreground">复诊安排:</span>
                                  <span>{record.follow_up}</span>
                                </div>
                                <Button
                                  className="mt-2 w-full bg-teal-500 hover:bg-teal-600 h-7 sm:h-8 text-[10px] sm:text-xs dark:bg-teal-600 dark:hover:bg-teal-700"
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    selectDiagnosis(record.id)
                                  }}
                                >
                                  {currentSession === record.id ? "已选择此诊断" : "解释这份诊断"}
                                </Button>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <FileText className="h-8 w-8 sm:h-12 sm:w-12 text-muted-foreground mx-auto mb-2" />
                        <p className="text-xs sm:text-sm">没有找到诊断记录</p>
                        <UploadDialog
                          buttonText="上传诊断记录"
                          onUploadSuccess={refreshDiagnosisRecords}
                          className="mt-4"
                        />
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="terms" className="flex-1 overflow-hidden mt-2">
              <Card className="h-full flex flex-col shadow-sm">
                <CardHeader className="bg-blue-50 dark:bg-blue-900/20 border-b border-blue-100 dark:border-blue-800/30 pb-2 flex-shrink-0 p-3">
                  <div className="flex justify-between items-center">
                    <CardTitle className="flex items-center text-sm sm:text-base">
                      <Info className="h-3 w-3 sm:h-4 sm:w-4 text-blue-500 dark:text-blue-400 mr-1 sm:mr-2" />
                      相关话题
                    </CardTitle>
                    <div className="relative w-24 sm:w-32">
                      <Search className="absolute left-2 top-2 h-3 w-3 text-muted-foreground" />
                      <Input
                        placeholder="搜索话题..."
                        className="pl-7 h-7 text-xs dark:bg-gray-800 dark:border-gray-700"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                  </div>
                  <CardDescription className="text-xs">点击话题获取详细解释</CardDescription>
                </CardHeader>

                <CardContent className="p-0 flex-1 overflow-hidden">
                  <ScrollArea className="h-[calc(100%-40px)]">
                    {isLoadingTerms ? (
                      <div className="flex items-center justify-center h-full">
                        <Loader2 className="h-8 w-8 animate-spin text-teal-500" />
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 gap-3 p-4">
                        {filteredMedicalTerms.length > 0 ? (
                          filteredMedicalTerms.map((term) => (
                            <Button
                              key={term.id}
                              variant="ghost"
                              className="justify-start h-auto py-2 px-3 text-xs w-full bg-background/80 dark:bg-gray-800/50 border border-border dark:border-gray-700 hover:bg-accent hover:text-accent-foreground dark:hover:bg-sidebar-accent dark:hover:text-sidebar-accent-foreground transition-colors duration-200 rounded-md"
                              onClick={() => explainMedicalTerm(term.term)}
                            >
                              <div className="flex items-center">
                                <Info className="h-3 w-3 sm:h-4 sm:w-4 text-blue-500 dark:text-blue-400 mr-2 flex-shrink-0" />
                                <span className="truncate">{term.term}</span>
                              </div>
                            </Button>
                          ))
                        ) : (
                          <div className="text-center py-8">
                            <Info className="h-8 w-8 sm:h-12 sm:w-12 text-muted-foreground mx-auto mb-2" />
                            <p className="text-xs sm:text-sm">
                              {selectedDiagnosisId ? "此诊断记录中没有找到相关话题" : "没有找到匹配的话题"}
                            </p>
                            <p className="text-xs text-muted-foreground mt-2">
                              您可以直接在对话框中输入问题，询问任何健康相关的话题
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* 移动端底部悬浮按钮 */}
      <div className="fixed right-4 bottom-4 md:hidden">
        <Button
          size="icon"
          className="h-12 w-12 rounded-full shadow-lg bg-teal-500 hover:bg-teal-600 text-white"
          onClick={() => setIsMobileMenuOpen(true)}
        >
          <Plus className="h-6 w-6" />
        </Button>
      </div>
    </div>
  )
}
