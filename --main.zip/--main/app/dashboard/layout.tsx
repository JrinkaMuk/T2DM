"use client"

import type React from "react"

import { useEffect, useState, useCallback } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { useTheme } from "@/components/theme-provider"
import { LayoutDashboard, MessageSquare, FileText, BarChart, Settings, LogOut, Moon, Sun } from "lucide-react"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <DashboardLayoutContent>{children}</DashboardLayoutContent>
}

function DashboardLayoutContent({ children }: { children: React.ReactNode }) {
  const { user, isLoading, logout } = useAuth()
  const router = useRouter()
  const { theme, setTheme } = useTheme()
  const [isMounted, setIsMounted] = useState(false)
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  // 检测是否为移动设备
  const [isMobile, setIsMobile] = useState(false)

  // 避免水合不匹配
  useEffect(() => {
    setIsMounted(true)

    // 检测移动设备
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
      // 在移动设备上默认折叠侧边栏
      if (window.innerWidth < 768) {
        setIsSidebarCollapsed(true)
      }
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  // 使用useCallback来确保toggleTheme函数不会在每次渲染时重新创建
  const toggleTheme = useCallback(() => {
    const newTheme = theme === "dark" ? "light" : "dark"
    setTheme(newTheme)
  }, [theme, setTheme])

  // 切换移动菜单
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen)
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500 mx-auto"></div>
          <p className="mt-4 text-lg">加载中...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="flex min-h-screen">
      {/* 侧边栏 - 桌面版 */}
      <div
        className={`fixed inset-y-0 left-0 z-30 transition-all duration-300 ${
          isSidebarCollapsed ? "w-16" : "w-16 md:w-64"
        } bg-gray-100 dark:bg-gray-900 border-r dark:border-gray-700 flex flex-col text-gray-800 dark:text-gray-200 shadow-md md:block ${
          isMobileMenuOpen ? "block" : "hidden"
        }`}
      >
        <div className="p-4 border-b dark:border-gray-700 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center space-x-2" onClick={() => setIsMobileMenuOpen(false)}>
            <span className={`font-bold text-xl ${isSidebarCollapsed ? "hidden" : "hidden md:inline"}`}>
              医疗健康助手
            </span>
            <span className={`font-bold text-xl ${isSidebarCollapsed ? "inline" : "md:hidden"}`}>医疗助手</span>
          </Link>
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="sm"
              className="md:flex hidden"
              onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
            >
              {isSidebarCollapsed ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M9 18l6-6-6-6" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M15 18l-6-6 6-6" />
                </svg>
              )}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden flex"
              onClick={toggleMobileMenu}
              aria-label="关闭菜单"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </Button>
          </div>
        </div>
        <nav className="mt-6 px-2 md:px-4 space-y-2 flex-1 overflow-y-auto">
          <Link href="/dashboard" onClick={() => setIsMobileMenuOpen(false)}>
            <Button
              variant="ghost"
              className="w-full justify-start transition-colors duration-200 hover:bg-gray-200 dark:hover:bg-gray-800 h-12"
            >
              <LayoutDashboard className="h-5 w-5 md:mr-3 md:h-5 md:w-5" />
              <span className={`${isSidebarCollapsed ? "hidden" : "inline md:inline"}`}>仪表盘</span>
            </Button>
          </Link>
          <Link href="/dashboard/chat" onClick={() => setIsMobileMenuOpen(false)}>
            <Button
              variant="ghost"
              className="w-full justify-start transition-colors duration-200 hover:bg-gray-200 dark:hover:bg-gray-800 h-12"
            >
              <MessageSquare className="h-5 w-5 md:mr-3 md:h-5 md:w-5" />
              <span className={`${isSidebarCollapsed ? "hidden" : "inline md:inline"}`}>健康对话</span>
            </Button>
          </Link>
          <Link href="/dashboard/reports" onClick={() => setIsMobileMenuOpen(false)}>
            <Button
              variant="ghost"
              className="w-full justify-start transition-colors duration-200 hover:bg-gray-200 dark:hover:bg-gray-800 h-12"
            >
              <FileText className="h-5 w-5 md:mr-3 md:h-5 md:w-5" />
              <span className={`${isSidebarCollapsed ? "hidden" : "inline md:inline"}`}>医疗报告</span>
            </Button>
          </Link>
          {/* 禁用分析选项 */}
          <Button
            variant="ghost"
            className="w-full justify-start transition-colors duration-200 h-12 opacity-50 cursor-not-allowed"
            disabled
          >
            <BarChart className="h-5 w-5 md:mr-3 md:h-5 md:w-5" />
            <span className={`${isSidebarCollapsed ? "hidden" : "inline md:inline"}`}>健康分析</span>
          </Button>
          {/* 禁用设置选项 */}
          <Button
            variant="ghost"
            className="w-full justify-start transition-colors duration-200 h-12 opacity-50 cursor-not-allowed"
            disabled
          >
            <Settings className="h-5 w-5 md:mr-3 md:h-5 md:w-5" />
            <span className={`${isSidebarCollapsed ? "hidden" : "inline md:inline"}`}>设置</span>
          </Button>
        </nav>
        <div className="p-4 border-t dark:border-gray-700">
          {isMounted && (
            <Button
              variant="outline"
              size="sm"
              className="mb-4 w-full dark:border-gray-600 dark:bg-gray-800 dark:hover:bg-gray-700 dark:text-white p-3 h-auto"
              onClick={toggleTheme}
              aria-label={theme === "dark" ? "切换到浅色模式" : "切换到深色模式"}
            >
              <div className="flex items-center justify-center w-full">
                {theme === "dark" ? <Sun className="h-5 w-5 text-yellow-500" /> : <Moon className="h-5 w-5" />}
                <span className={`ml-2 ${isSidebarCollapsed ? "hidden" : "inline md:inline"}`}>
                  {theme === "dark" ? "浅色模式" : "深色模式"}
                </span>
              </div>
            </Button>
          )}
          <Button
            variant="ghost"
            className="w-full justify-start text-red-500 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900/30 dark:hover:text-red-300 h-12"
            onClick={async () => {
              await logout()
              router.push("/login")
            }}
          >
            <LogOut className="h-5 w-5 md:mr-3 md:h-5 md:w-5" />
            <span className={`${isSidebarCollapsed ? "hidden" : "inline md:inline"}`}>退出登录</span>
          </Button>
        </div>
      </div>

      {/* 主内容区 */}
      <div
        className={`flex-1 flex flex-col ml-0 md:ml-16 ${
          isSidebarCollapsed ? "md:ml-16" : "md:ml-64"
        } transition-all duration-300`}
      >
        <header className="h-16 border-b dark:border-gray-700 bg-white dark:bg-gray-900 flex items-center px-4 md:px-6 text-gray-800 dark:text-gray-200">
          <div className="flex-1 flex items-center">
            <Button
              variant="ghost"
              size="icon"
              className="mr-2 md:hidden p-2 h-10 w-10"
              onClick={toggleMobileMenu}
              aria-label="打开菜单"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="3" y1="12" x2="21" y2="12" />
                <line x1="3" y1="6" x2="21" y2="6" />
                <line x1="3" y1="18" x2="21" y2="18" />
              </svg>
            </Button>
            <h1 className="text-base md:text-lg font-medium text-gray-800 dark:text-gray-200 truncate">
              欢迎, {user.name}
            </h1>
          </div>
          <div className="flex items-center space-x-2">
            {isMounted && (
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                aria-label={theme === "dark" ? "切换到浅色模式" : "切换到深色模式"}
                className="dark:text-white dark:hover:bg-gray-800 p-2 h-10 w-10"
              >
                {theme === "dark" ? <Sun className="h-5 w-5 text-yellow-500" /> : <Moon className="h-5 w-5" />}
              </Button>
            )}
          </div>
        </header>
        <main className="flex-1 p-3 md:p-6 overflow-auto dark:bg-gray-900">{children}</main>
      </div>
    </div>
  )
}
