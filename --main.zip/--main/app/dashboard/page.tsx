"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import {
  MessageSquare,
  FileText,
  Activity,
  Calendar,
  TrendingUp,
  AlertCircle,
  Heart,
  ChevronRight,
  Upload,
  Mic,
  MicOff,
  Play,
  Trash2,
} from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { UploadDialog } from "@/components/upload-dialog"
import { createClientComponentClient } from "@/lib/supabase"
import { useRouter } from "next/navigation"
import { useChat } from "@/contexts/chat-context"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

export default function DashboardPage() {
  const { user } = useAuth()
  const router = useRouter()
  const { setCurrentSession, updateSession } = useChat()
  const [diagnosisRecords, setDiagnosisRecords] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()
  const [refreshTrigger, setRefreshTrigger] = useState(0)

  // 录音相关状态
  const [isRecording, setIsRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [showSavedDialog, setShowSavedDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [selectedRecording, setSelectedRecording] = useState<number | null>(null)
  const [recordings, setRecordings] = useState([
    {
      id: 1,
      doctor: "张医生",
      date: "2023-05-15",
      time: "14:30",
      duration: "12:45",
      notes: "血糖控制情况讨论，调整胰岛素用量",
    },
    {
      id: 2,
      doctor: "李医生",
      date: "2023-05-01",
      time: "10:15",
      duration: "08:22",
      notes: "足部检查，讨论饮食计划",
    },
  ])

  // Function to refresh diagnosis records
  const refreshDiagnosisRecords = () => {
    setRefreshTrigger((prev) => prev + 1)
  }

  useEffect(() => {
    if (user) {
      fetchDiagnosisRecords()
    }
  }, [user, refreshTrigger])

  const fetchDiagnosisRecords = async () => {
    if (!user) return

    setIsLoading(true)
    try {
      const supabase = createClientComponentClient()
      const { data, error } = await supabase
        .from("diagnosis_records")
        .select("*")
        .eq("user_id", user.id)
        .order("date", { ascending: false })
        .limit(5)

      if (error) {
        throw error
      }

      setDiagnosisRecords(data || [])
    } catch (error) {
      console.error("Error fetching diagnosis records:", error)
      toast({
        title: "获取诊断记录失败",
        description: "请稍后再试",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDiagnosisClick = (diagnosisId: string) => {
    // 设置当前会话ID为诊断ID
    setCurrentSession(diagnosisId)

    // 确保会话中有选定的诊断ID
    updateSession(diagnosisId, {
      selectedDiagnosisId: diagnosisId,
      // 不要重置messages，保留现有消息
    })

    // 导航到聊天页面
    router.push("/dashboard/chat")
  }

  // 录音计时器效果
  useEffect(() => {
    let interval: NodeJS.Timeout

    if (isRecording) {
      interval = setInterval(() => {
        setRecordingTime((prevTime) => prevTime + 1)
      }, 1000)
    } else if (!isRecording && recordingTime !== 0) {
      clearInterval(interval)
    }

    return () => clearInterval(interval)
  }, [isRecording, recordingTime])

  // 格式化时间
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  // 处理录音开始/停止
  const handleRecordToggle = () => {
    if (!isRecording) {
      // 开始录音
      setIsRecording(true)
      setRecordingTime(0)
    } else {
      // 停止录音并显示保存对话框
      setIsRecording(false)
      setShowSavedDialog(true)

      // 模拟触觉反馈
      if (navigator.vibrate) {
        navigator.vibrate(150)
      }

      // 2秒后自动关闭对话框
      setTimeout(() => {
        setShowSavedDialog(false)
      }, 2000)
    }
  }

  // 处理删除录音
  const handleDeleteRecording = (id: number) => {
    setSelectedRecording(id)
    setShowDeleteDialog(true)
  }

  return (
    <div className="space-y-5">
      {/* 欢迎区域 - 突出显示 */}
      <div className="bg-gradient-to-r from-teal-500 to-teal-600 dark:from-teal-700 dark:to-teal-800 rounded-xl p-3 sm:p-6 text-white shadow-lg">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-4">
          <div>
            <h1 className="text-xl sm:text-3xl font-bold">欢迎回来，{user?.name || "用户"}</h1>
            <p className="mt-1 sm:mt-2 text-sm text-teal-100 dark:text-teal-200">
              今天是{" "}
              {new Date().toLocaleDateString("zh-CN", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </p>
          </div>
          <div className="flex flex-wrap gap-2 sm:gap-3 w-full sm:w-auto">
            <Link href="/dashboard/chat" className="w-full sm:w-auto">
              <Button
                variant="secondary"
                className="bg-white text-teal-600 hover:bg-teal-50 text-sm w-full sm:w-auto dark:bg-gray-800 dark:text-teal-400 dark:hover:bg-gray-700"
              >
                <MessageSquare className="mr-2 h-4 w-4" />
                开始健康对话
              </Button>
            </Link>
            <Button
              variant="secondary"
              className="bg-white text-red-600 hover:bg-red-50 text-sm w-full sm:w-auto dark:bg-gray-800 dark:text-red-400 dark:hover:bg-gray-700"
              onClick={handleRecordToggle}
            >
              {isRecording ? (
                <>
                  <MicOff className="mr-2 h-4 w-4" />
                  {formatTime(recordingTime)} 停止录音
                </>
              ) : (
                <>
                  <Mic className="mr-2 h-4 w-4" />
                  医生问诊录音
                </>
              )}
            </Button>
            <UploadDialog onUploadSuccess={refreshDiagnosisRecords} className="w-full sm:w-auto" />
          </div>
        </div>
      </div>

      {/* 诊断记录模块 - 条件渲染 */}
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 dark:from-blue-700 dark:to-blue-800 rounded-xl p-3 sm:p-6 text-white shadow-lg">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-4 mb-3 sm:mb-4">
          <div>
            <h2 className="text-lg sm:text-2xl font-bold">您的诊断记录</h2>
            <p className="mt-1 text-sm text-blue-100 dark:text-blue-200">
              {isLoading
                ? "加载中..."
                : diagnosisRecords.length > 0
                  ? `您已上传 ${diagnosisRecords.length} 份诊断记录，点击查看详情`
                  : "您还没有上传诊断记录"}
            </p>
          </div>
          <Link href="/dashboard/chat">
            <Button
              variant="secondary"
              className="bg-white text-blue-600 hover:bg-blue-50 text-sm w-full sm:w-auto dark:bg-gray-800 dark:text-blue-400 dark:hover:bg-gray-700"
            >
              查看全部
              <ChevronRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-6 sm:py-8">
            <div className="animate-spin rounded-full h-10 sm:h-12 w-10 sm:w-12 border-b-2 border-white"></div>
          </div>
        ) : diagnosisRecords.length > 0 ? (
          <div className="grid gap-3 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 overflow-y-auto max-h-[180px] pr-1">
            {diagnosisRecords.slice(0, 3).map((record) => (
              <div
                key={record.id}
                className="bg-white/10 backdrop-blur-sm rounded-lg p-3 cursor-pointer hover:bg-white/20 transition-colors"
                onClick={() => handleDiagnosisClick(record.id)}
              >
                <div className="flex items-center mb-2">
                  <Calendar className="h-4 w-4 mr-2 text-blue-200 flex-shrink-0" />
                  <span className="font-medium truncate">{record.date}</span>
                  {record.medications && record.medications.length > 0 && (
                    <Badge className="ml-2 bg-blue-700 text-white text-xs">{record.medications.length}种药物</Badge>
                  )}
                </div>
                <p className="text-sm text-blue-100 line-clamp-2">{record.diagnosis}</p>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center text-center py-4">
            <Upload className="h-10 sm:h-12 w-10 sm:w-12 mb-3 sm:mb-4 text-blue-200" />
            <h2 className="text-lg sm:text-2xl font-bold mb-2">上传您的第一份诊断记录</h2>
            <p className="mb-4 text-sm text-blue-100 dark:text-blue-200 max-w-md">
              上传您的诊断记录，AI助手将帮助您理解医学术语和诊断结果，让复杂的医疗信息变得简单易懂。
            </p>

            <button
              onClick={handleRecordToggle}
              className="w-16 h-16 rounded-full bg-green-500 hover:bg-green-600 flex items-center justify-center shadow-lg mb-4"
            >
              {isRecording ? <MicOff className="h-8 w-8 text-white" /> : <Mic className="h-8 w-8 text-white" />}
            </button>
            <p className="mb-4 text-sm text-blue-100 dark:text-blue-200">请点击录音，系统将自动记录诊断</p>

            <UploadDialog onUploadSuccess={refreshDiagnosisRecords} buttonText="立即上传诊断记录" />
          </div>
        )}
      </div>

      {/* 近期录音 */}
      <div className="mb-8">
        <h2 className="text-lg sm:text-2xl font-bold tracking-tight mb-3 sm:mb-4 dark:text-white">近期问诊录音</h2>
        <div className="grid gap-3 sm:gap-4 grid-cols-1 md:grid-cols-2">
          {recordings.map((recording) => (
            <Card key={recording.id} className="border-2 border-gray-200 dark:border-gray-700">
              <CardContent className="p-3 sm:p-4">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center">
                    <div className="text-base sm:text-lg font-bold dark:text-white">{recording.doctor}</div>
                    <Badge variant="outline" className="ml-2 text-xs sm:text-sm">
                      {recording.duration}
                    </Badge>
                  </div>
                  <div className="flex">
                    <Button variant="ghost" size="icon" className="h-8 w-8 sm:h-10 sm:w-10">
                      <Play className="h-4 w-4 sm:h-5 sm:w-5 text-teal-500 dark:text-teal-400" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 sm:h-10 sm:w-10 text-red-500 dark:text-red-400"
                      onClick={() => handleDeleteRecording(recording.id)}
                    >
                      <Trash2 className="h-4 w-4 sm:h-5 sm:w-5" />
                    </Button>
                  </div>
                </div>
                <div className="flex items-center text-xs sm:text-sm text-gray-500 dark:text-gray-400 mb-2">
                  <Calendar className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                  {recording.date}
                  <span className="mx-1 sm:mx-2">|</span>
                  {recording.time}
                </div>
                <p className="text-xs sm:text-sm dark:text-gray-300">{recording.notes}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* 主要健康指标 - 突出显示关键数据 */}
      <div>
        <h2 className="text-lg sm:text-2xl font-bold tracking-tight mb-3 sm:mb-4 dark:text-white">健康概览</h2>
        <div className="grid gap-3 sm:gap-4 grid-cols-2 sm:grid-cols-2 lg:grid-cols-4">
          <Card className="border-l-4 border-l-teal-500 dark:bg-gray-800 dark:border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-3 sm:p-4">
              <CardTitle className="text-xs sm:text-sm font-medium">今日步数</CardTitle>
              <Activity className="h-4 w-4 text-teal-500 dark:text-teal-400" />
            </CardHeader>
            <CardContent className="p-3 sm:p-4 pt-0">
              <div className="text-lg sm:text-3xl font-bold">7,842</div>
              <div className="flex items-center mt-1">
                <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4 text-green-500 dark:text-green-400 mr-1" />
                <p className="text-xs text-green-500 dark:text-green-400">+20% 相比昨天</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-blue-500 dark:bg-gray-800 dark:border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-3 sm:p-4">
              <CardTitle className="text-xs sm:text-sm font-medium">健康记录</CardTitle>
              <Calendar className="h-4 w-4 text-blue-500 dark:text-blue-400" />
            </CardHeader>
            <CardContent className="p-3 sm:p-4 pt-0">
              <div className="text-lg sm:text-3xl font-bold">12</div>
              <p className="text-xs text-muted-foreground mt-1">本月记录</p>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-purple-500 dark:bg-gray-800 dark:border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-3 sm:p-4">
              <CardTitle className="text-xs sm:text-sm font-medium">对话次数</CardTitle>
              <MessageSquare className="h-4 w-4 text-purple-500 dark:text-purple-400" />
            </CardHeader>
            <CardContent className="p-3 sm:p-4 pt-0">
              <div className="text-lg sm:text-3xl font-bold">24</div>
              <p className="text-xs text-muted-foreground mt-1">过去30天</p>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-amber-500 dark:bg-gray-800 dark:border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-3 sm:p-4">
              <CardTitle className="text-xs sm:text-sm font-medium">生成报告</CardTitle>
              <FileText className="h-4 w-4 text-amber-500 dark:text-amber-400" />
            </CardHeader>
            <CardContent className="p-3 sm:p-4 pt-0">
              <div className="text-lg sm:text-3xl font-bold">3</div>
              <p className="text-xs text-muted-foreground mt-1">已生成报告</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 健康数据和健康提示 - 并排显示 */}
      <div className="grid gap-4 md:grid-cols-2">
        {/* 健康数据图表 */}
        <Card className="dark:bg-gray-800 dark:border-gray-700">
          <CardHeader className="p-3 sm:p-6">
            <CardTitle className="flex items-center text-base sm:text-xl">
              <Heart className="h-4 sm:h-5 w-4 sm:w-5 text-red-500 dark:text-red-400 mr-2" />
              健康趋势
            </CardTitle>
            <CardDescription className="dark:text-gray-400">查看您的健康数据趋势</CardDescription>
          </CardHeader>
          <CardContent className="pl-2 p-3 sm:p-6 pt-0">
            <div className="h-[200px] sm:h-[250px] md:h-[300px] flex items-center justify-center bg-gray-50 dark:bg-gray-800 rounded-md">
              <div className="text-center">
                <TrendingUp className="h-8 w-8 sm:h-12 sm:w-12 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">健康数据图表将在这里显示</p>
                <Button variant="outline" className="mt-4 text-xs sm:text-sm dark:border-gray-700 dark:text-gray-200">
                  查看详细数据
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 健康提示 */}
        <Card className="border border-amber-200 bg-amber-50 dark:bg-amber-950/20 dark:border-amber-800/30">
          <CardHeader className="p-3 sm:p-6">
            <CardTitle className="flex items-center text-base sm:text-xl">
              <AlertCircle className="h-4 sm:h-5 w-4 sm:w-5 text-amber-500 dark:text-amber-400 mr-2" />
              健康提示
            </CardTitle>
            <CardDescription>基于您的健康数据的个性化提示</CardDescription>
          </CardHeader>
          <CardContent className="p-3 sm:p-6 pt-0">
            <div className="space-y-3">
              <div className="rounded-lg border border-amber-200 bg-white dark:bg-gray-800 dark:border-amber-800/30 p-3">
                <h3 className="font-medium text-amber-700 dark:text-amber-400 text-sm sm:text-base">增加水分摄入</h3>
                <p className="text-xs sm:text-sm text-muted-foreground mt-1">
                  根据您的记录，建议每天增加500ml水的摄入量
                </p>
              </div>
              <div className="rounded-lg border border-amber-200 bg-white dark:bg-gray-800 dark:border-amber-800/30 p-3">
                <h3 className="font-medium text-amber-700 dark:text-amber-400 text-sm sm:text-base">增加步行时间</h3>
                <p className="text-xs sm:text-sm text-muted-foreground mt-1">
                  尝试每天步行30分钟，有助于改善心血管健康
                </p>
              </div>
              <div className="rounded-lg border border-amber-200 bg-white dark:bg-gray-800 dark:border-amber-800/30 p-3">
                <h3 className="font-medium text-amber-700 dark:text-amber-400 text-sm sm:text-base">减少加工食品</h3>
                <p className="text-xs sm:text-sm text-muted-foreground mt-1">建议减少加工食品的摄入，增加新鲜蔬果</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 最近活动 */}
      <Card className="dark:bg-gray-800 dark:border-gray-700">
        <CardHeader className="p-3 sm:p-6">
          <CardTitle className="flex items-center text-base sm:text-xl">
            <Activity className="h-4 sm:h-5 w-4 sm:w-5 text-teal-500 dark:text-teal-400 mr-2" />
            最近活动
          </CardTitle>
          <CardDescription className="dark:text-gray-400">您最近的健康记录和对话</CardDescription>
        </CardHeader>
        <CardContent className="p-3 sm:p-6 pt-0">
          <div className="space-y-3">
            <div className="flex items-center bg-gray-50 dark:bg-gray-800 dark:border dark:border-gray-700 p-3 rounded-lg">
              <div className="mr-3 sm:mr-4 rounded-full bg-teal-100 dark:bg-teal-900/50 p-2">
                <MessageSquare className="h-4 w-4 text-teal-500 dark:text-teal-400" />
              </div>
              <div className="flex-1 space-y-1 min-w-0">
                <p className="text-xs sm:text-sm font-medium leading-none">健康对话</p>
                <p className="text-xs text-muted-foreground dark:text-gray-400 truncate">关于饮食建议的对话</p>
              </div>
              <div className="text-xs sm:text-sm text-muted-foreground dark:text-gray-400 ml-2 flex-shrink-0">
                2小时前
              </div>
            </div>
            <div className="flex items-center bg-gray-50 dark:bg-gray-800 dark:border dark:border-gray-700 p-3 rounded-lg">
              <div className="mr-3 sm:mr-4 rounded-full bg-teal-100 dark:bg-teal-900/50 p-2">
                <Calendar className="h-4 w-4 text-teal-500 dark:text-teal-400" />
              </div>
              <div className="flex-1 space-y-1 min-w-0">
                <p className="text-xs sm:text-sm font-medium leading-none">健康记录</p>
                <p className="text-xs text-muted-foreground dark:text-gray-400 truncate">记录了今日运动数据</p>
              </div>
              <div className="text-xs sm:text-sm text-muted-foreground dark:text-gray-400 ml-2 flex-shrink-0">昨天</div>
            </div>
            <div className="flex items-center bg-gray-50 dark:bg-gray-800 dark:border dark:border-gray-700 p-3 rounded-lg">
              <div className="mr-3 sm:mr-4 rounded-full bg-teal-100 dark:bg-teal-900/50 p-2">
                <FileText className="h-4 w-4 text-teal-500 dark:text-teal-400" />
              </div>
              <div className="flex-1 space-y-1 min-w-0">
                <p className="text-xs sm:text-sm font-medium leading-none">生成报告</p>
                <p className="text-xs text-muted-foreground dark:text-gray-400 truncate">生成了月度健康报告</p>
              </div>
              <div className="text-xs sm:text-sm text-muted-foreground dark:text-gray-400 ml-2 flex-shrink-0">
                3天前
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 录音保存对话框 */}
      <Dialog open={showSavedDialog} onOpenChange={setShowSavedDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl text-center">录音已保存!</DialogTitle>
          </DialogHeader>
          <div className="flex justify-center my-4">
            <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
              <Mic className="h-8 w-8 text-green-600 dark:text-green-400" />
            </div>
          </div>
          <DialogDescription className="text-center text-xl">您的医生问诊录音已成功保存</DialogDescription>
        </DialogContent>
      </Dialog>

      {/* 删除确认对话框 */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl">确认删除录音?</DialogTitle>
          </DialogHeader>
          <DialogDescription className="text-lg">此操作无法撤销，录音将被永久删除。</DialogDescription>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" className="text-lg flex-1" onClick={() => setShowDeleteDialog(false)}>
              取消
            </Button>
            <Button
              variant="destructive"
              className="text-lg flex-1"
              onClick={() => {
                // 处理删除逻辑
                setRecordings(recordings.filter((r) => r.id !== selectedRecording))
                setShowDeleteDialog(false)
              }}
            >
              确认删除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
