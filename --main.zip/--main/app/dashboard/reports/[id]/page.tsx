"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { clientDataService } from "@/lib/data-service"
import { ArrowLeft, Download, Calendar, FileText, MessageSquare } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export default function ReportDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { user } = useAuth()
  const { toast } = useToast()
  const [report, setReport] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [relatedDiagnoses, setRelatedDiagnoses] = useState<any[]>([])
  const [isMobile, setIsMobile] = useState(false)

  // 检测移动设备
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  useEffect(() => {
    if (!user) return

    const reportId = params.id as string

    // 如果 ID 是 "new"，则不尝试获取报告
    if (reportId === "new") {
      setIsLoading(false)
      return
    }

    const fetchReport = async () => {
      setIsLoading(true)
      try {
        const reportData = await clientDataService.getHealthReportById(reportId)
        setReport(reportData)

        // 获取相关的诊断记录
        if (reportData.diagnosis_ids && reportData.diagnosis_ids.length > 0) {
          const diagnoses = await Promise.all(
            reportData.diagnosis_ids.map((id: string) => clientDataService.getDiagnosisRecord(id)),
          )
          setRelatedDiagnoses(diagnoses.filter(Boolean))
        }
      } catch (error) {
        console.error("Error fetching report:", error)
        toast({
          title: "获取报告失败",
          description: "请稍后再试",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchReport()
  }, [params.id, user, toast])

  const handleDownload = () => {
    if (!report) return

    // 创建一个Blob对象
    const blob = new Blob([report.content], { type: "text/plain;charset=utf-8" })

    // 创建一个下载链接
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${report.title}.txt`
    document.body.appendChild(a)
    a.click()

    // 清理
    setTimeout(() => {
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    }, 0)
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("zh-CN", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <Button
          variant="outline"
          size="sm"
          onClick={() => router.push("/dashboard/reports")}
          className="dark:border-gray-700 dark:text-gray-300 w-full sm:w-auto"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          返回报告列表
        </Button>

        {!isLoading && report && (
          <Button onClick={handleDownload} className="bg-teal-500 hover:bg-teal-600 w-full sm:w-auto">
            <Download className="mr-2 h-4 w-4" />
            下载报告
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="space-y-4">
          <Skeleton className="h-12 w-3/4" />
          <Skeleton className="h-6 w-1/2" />
          <Skeleton className="h-[600px] w-full" />
        </div>
      ) : report ? (
        <div className="space-y-5">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight break-words">{report.title}</h1>
            <div className="flex flex-wrap items-center mt-2 text-muted-foreground gap-2">
              <div className="flex items-center">
                <Calendar className="mr-2 h-4 w-4 flex-shrink-0" />
                <span>生成于 {formatDate(report.created_at)}</span>
              </div>
              <Badge className="bg-teal-500">{report.report_type}</Badge>
            </div>
          </div>

          {relatedDiagnoses.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">相关诊断记录</CardTitle>
                <CardDescription>此报告基于以下诊断记录生成</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                  {relatedDiagnoses.map((diagnosis) => (
                    <div
                      key={diagnosis.id}
                      className="border rounded-lg p-3 hover:border-teal-200 hover:bg-gray-50 dark:hover:bg-gray-800/50 dark:border-gray-700"
                    >
                      <div className="flex items-center mb-2">
                        <FileText className="h-4 w-4 text-teal-500 dark:text-teal-400 mr-2 flex-shrink-0" />
                        <span className="font-medium truncate">{diagnosis.date}</span>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2">{diagnosis.diagnosis}</p>
                      <Button
                        variant="link"
                        size="sm"
                        className="mt-2 h-auto p-0 text-teal-500"
                        onClick={() => router.push(`/dashboard/chat?diagnosis=${diagnosis.id}`)}
                      >
                        <MessageSquare className="h-3 w-3 mr-1" />
                        查看对话
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>报告内容</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose dark:prose-invert max-w-none text-sm sm:text-base">
                {report.content.split("\n").map((paragraph: string, index: number) => {
                  // 检查是否是标题行
                  if (paragraph.match(/^[0-9]+\.\s+.+/) || paragraph.match(/^[一二三四五六七八九十]+、\s+.+/)) {
                    return (
                      <h3 key={index} className="font-bold mt-6 mb-2">
                        {paragraph}
                      </h3>
                    )
                  }
                  // 空行
                  if (!paragraph.trim()) {
                    return <br key={index} />
                  }
                  // 普通段落
                  return (
                    <p key={index} className="mb-4">
                      {paragraph}
                    </p>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="text-center py-12">
          <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">未找到报告</h2>
          <p className="text-muted-foreground">该报告可能已被删除或您没有权限查看</p>
          <Button className="mt-4 bg-teal-500 hover:bg-teal-600" onClick={() => router.push("/dashboard/reports")}>
            返回报告列表
          </Button>
        </div>
      )}
    </div>
  )
}
