"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { FileText, MessageSquare, Activity } from "lucide-react"

export default function NewReportPage() {
  const [title, setTitle] = useState("")
  const [reportType, setReportType] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!title || !reportType) {
      toast({
        title: "请填写所有必填字段",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      // 模拟API调用
      await new Promise((resolve) => setTimeout(resolve, 2000))

      toast({
        title: "报告创建成功",
        description: "您的报告已成功生成",
      })

      router.push("/dashboard/reports")
    } catch (error) {
      toast({
        title: "创建报告失败",
        description: "请稍后再试",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">创建新报告</h2>
        <p className="text-muted-foreground">生成一份包含您健康数据的结构化报告</p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>报告信息</CardTitle>
              <CardDescription>设置报告的基本信息</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">报告标题</Label>
                <Input
                  id="title"
                  placeholder="例如：月度健康报告 - 2023年4月"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="report-type">报告类型</Label>
                <Select value={reportType} onValueChange={setReportType} required>
                  <SelectTrigger id="report-type">
                    <SelectValue placeholder="选择报告类型" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monthly">月度报告</SelectItem>
                    <SelectItem value="quarterly">季度报告</SelectItem>
                    <SelectItem value="annual">年度报告</SelectItem>
                    <SelectItem value="custom">自定义报告</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">报告描述（可选）</Label>
                <Textarea id="description" placeholder="描述这份报告的目的和内容..." rows={4} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>数据选择</CardTitle>
              <CardDescription>选择要包含在报告中的数据</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>包含的数据类型</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="health-records" defaultChecked />
                    <Label htmlFor="health-records" className="flex items-center">
                      <Activity className="mr-2 h-4 w-4" />
                      健康记录
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="conversations" defaultChecked />
                    <Label htmlFor="conversations" className="flex items-center">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      对话记录
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="medical-terms" defaultChecked />
                    <Label htmlFor="medical-terms" className="flex items-center">
                      <FileText className="mr-2 h-4 w-4" />
                      医疗术语解释
                    </Label>
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="date-range">日期范围</Label>
                <Select defaultValue="last-month">
                  <SelectTrigger id="date-range">
                    <SelectValue placeholder="选择日期范围" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="last-week">过去一周</SelectItem>
                    <SelectItem value="last-month">过去一个月</SelectItem>
                    <SelectItem value="last-quarter">过去三个月</SelectItem>
                    <SelectItem value="last-year">过去一年</SelectItem>
                    <SelectItem value="custom">自定义范围</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>报告格式</Label>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="format-pdf" defaultChecked />
                    <Label htmlFor="format-pdf">PDF</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="format-word" defaultChecked />
                    <Label htmlFor="format-word">Word</Label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-6 flex justify-end space-x-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => router.push("/dashboard/reports")}
            disabled={isLoading}
          >
            取消
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? "生成中..." : "生成报告"}
          </Button>
        </div>
      </form>
    </div>
  )
}
