"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { FileText, Plus, Search, Download, Calendar } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { createClientComponentClient } from "@/lib/supabase"
import { ReportDialog } from "@/components/report-dialog"
import { useToast } from "@/hooks/use-toast"

export default function ReportsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [reports, setReports] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { user } = useAuth()
  const { toast } = useToast()
  const [isMobile, setIsMobile] = useState(false)

  // 检测移动设备
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  useEffect(() => {
    if (user) {
      fetchReports()
    }
  }, [user])

  const fetchReports = async () => {
    if (!user) return

    setIsLoading(true)
    try {
      const supabase = createClientComponentClient()

      // 使用 health_reports 表而不是 reports 表
      const { data, error } = await supabase
        .from("health_reports")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Error fetching reports:", error)
        throw error
      }

      setReports(data || [])
    } catch (error) {
      console.error("Error fetching reports:", error)
      toast({
        title: "获取报告失败",
        description: "请稍后再试",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const filteredReports = reports.filter(
    (report) =>
      report.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.report_type.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // 格式化日期
  const formatDate = (dateString: string) => {
    if (!dateString) return "未知日期"
    const date = new Date(dateString)
    return date.toLocaleDateString("zh-CN", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">医疗报告</h2>
          <p className="text-sm text-muted-foreground mt-1">查看和生成您的医疗健康报告</p>
        </div>
        <div className="flex flex-wrap gap-2 w-full sm:w-auto">
          <ReportDialog onReportCreated={fetchReports} className="w-full sm:w-auto" />
          <Link href="/dashboard/reports/new" className="w-full sm:w-auto">
            <Button className="w-full sm:w-auto">
              <Plus className="mr-2 h-4 w-4" />
              新建报告
            </Button>
          </Link>
        </div>
      </div>

      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="搜索报告..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500"></div>
        </div>
      ) : (
        <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
          {filteredReports.map((report) => (
            <Card key={report.id} className="overflow-hidden flex flex-col">
              <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2 p-3 sm:p-4">
                <div className="space-y-1 min-w-0 flex-1 pr-2">
                  <CardTitle className="text-lg font-bold line-clamp-1">{report.title}</CardTitle>
                  <CardDescription>
                    <div className="flex items-center mt-1">
                      <Calendar className="mr-1 h-3 w-3 flex-shrink-0" />
                      <span className="truncate">{formatDate(report.created_at)}</span>
                    </div>
                  </CardDescription>
                </div>
                <div className="rounded-full px-2 py-1 text-xs bg-primary/10 text-primary whitespace-nowrap">
                  {report.report_type || "健康报告"}
                </div>
              </CardHeader>
              <CardContent className="p-3 sm:p-4 pt-0 flex-1">
                <p className="text-sm text-muted-foreground line-clamp-3">
                  {report.content ? report.content.substring(0, 150) + "..." : "无内容"}
                </p>
              </CardContent>
              <CardFooter className="flex justify-between pt-2 p-3 sm:p-4 border-t">
                <Link href={`/dashboard/reports/${report.id}`}>
                  <Button variant="outline" size="sm">
                    <FileText className="mr-2 h-4 w-4" />
                    查看
                  </Button>
                </Link>
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  下载
                </Button>
              </CardFooter>
            </Card>
          ))}

          {filteredReports.length === 0 && (
            <div className="col-span-full flex flex-col items-center justify-center rounded-lg border border-dashed p-6 sm:p-8 text-center">
              <div className="mx-auto flex h-16 sm:h-20 w-16 sm:w-20 items-center justify-center rounded-full bg-primary/10">
                <FileText className="h-8 sm:h-10 w-8 sm:w-10 text-primary" />
              </div>
              <h3 className="mt-4 text-base sm:text-lg font-semibold">没有找到报告</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                {searchTerm ? "没有找到匹配的报告，请尝试其他搜索词。" : "您还没有创建任何报告。"}
              </p>
              {!searchTerm && (
                <div className="mt-4 flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                  <ReportDialog onReportCreated={fetchReports} className="w-full sm:w-auto" />
                  <Link href="/dashboard/reports/new" className="w-full sm:w-auto">
                    <Button className="w-full sm:w-auto">
                      <Plus className="mr-2 h-4 w-4" />
                      创建报告
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
