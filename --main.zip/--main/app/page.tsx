"use client"

import { useState } from "react"
import { Tabs, TabsContent } from "@/components/ui/tabs"
import { HomeScreen } from "@/components/home-screen"
import { FamilyDashboard } from "@/components/family-dashboard"
import { ProfileSettings } from "@/components/profile-settings"
import { Home, Users, User } from "lucide-react"

export default function App() {
  const [activeTab, setActiveTab] = useState("home")

  return (
    <div className="flex flex-col h-screen bg-gray-50 dark:bg-gray-900 overflow-hidden">
      <main className="flex-1 overflow-auto pb-16">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
          <TabsContent value="home" className="h-full m-0 p-0">
            <HomeScreen />
          </TabsContent>
          <TabsContent value="family" className="h-full m-0 p-0">
            <FamilyDashboard />
          </TabsContent>
          <TabsContent value="profile" className="h-full m-0 p-0">
            <ProfileSettings />
          </TabsContent>
        </Tabs>
      </main>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 h-16 flex items-center justify-around">
        <button
          onClick={() => setActiveTab("home")}
          className={`flex flex-col items-center justify-center w-1/3 h-full ${
            activeTab === "home" ? "text-teal-500" : "text-gray-500 dark:text-gray-400"
          }`}
        >
          <Home size={28} />
          <span className="text-lg mt-1">首页</span>
        </button>
        <button
          onClick={() => setActiveTab("family")}
          className={`flex flex-col items-center justify-center w-1/3 h-full ${
            activeTab === "family" ? "text-teal-500" : "text-gray-500 dark:text-gray-400"
          }`}
        >
          <Users size={28} />
          <span className="text-lg mt-1">家人</span>
        </button>
        <button
          onClick={() => setActiveTab("profile")}
          className={`flex flex-col items-center justify-center w-1/3 h-full ${
            activeTab === "profile" ? "text-teal-500" : "text-gray-500 dark:text-gray-400"
          }`}
        >
          <User size={28} />
          <span className="text-lg mt-1">我的</span>
        </button>
      </div>
    </div>
  )
}
