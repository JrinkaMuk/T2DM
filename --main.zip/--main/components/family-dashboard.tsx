"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { TrendingUp, Bell, Eye, UserPlus, Phone, MessageSquare, Shield, ShieldAlert, Activity } from "lucide-react"

export function FamilyDashboard() {
  const [showPermissionDialog, setShowPermissionDialog] = useState(false)
  const [selectedMember, setSelectedMember] = useState<string | null>(null)

  // Mock data for family members
  const familyMembers = [
    {
      id: 1,
      name: "张小明",
      relation: "儿子",
      permissions: ["查看血糖", "查看用药", "查看录音", "紧急联系人"],
      phone: "138****1234",
      lastActive: "今天 14:30",
    },
    {
      id: 2,
      name: "李丽",
      relation: "女儿",
      permissions: ["查看血糖", "查看用药", "紧急联系人"],
      phone: "139****5678",
      lastActive: "昨天 09:15",
    },
    {
      id: 3,
      name: "王医生",
      relation: "主治医生",
      permissions: ["查看血糖", "查看用药", "查看录音"],
      phone: "133****9012",
      lastActive: "3天前",
    },
  ]

  // Mock data for glucose readings
  const glucoseReadings = [
    { time: "今天 08:00", value: 7.2, status: "normal" },
    { time: "今天 12:30", value: 11.2, status: "high" },
    { time: "昨天 08:00", value: 6.8, status: "normal" },
    { time: "昨天 12:30", value: 8.5, status: "elevated" },
    { time: "昨天 18:00", value: 7.9, status: "normal" },
    { time: "前天 08:00", value: 6.5, status: "normal" },
    { time: "前天 12:30", value: 9.2, status: "elevated" },
    { time: "前天 18:00", value: 7.1, status: "normal" },
  ]

  // Mock data for medication adherence
  const medicationAdherence = [
    { date: "今天", morning: true, noon: true, evening: false },
    { date: "昨天", morning: true, noon: true, evening: true },
    { date: "前天", morning: true, noon: false, evening: true },
    { date: "5月12日", morning: true, noon: true, evening: true },
    { date: "5月11日", morning: true, noon: true, evening: false },
    { date: "5月10日", morning: false, noon: true, evening: true },
  ]

  const handlePermissionClick = (name: string) => {
    setSelectedMember(name)
    setShowPermissionDialog(true)
  }

  return (
    <div className="p-4 pb-20">
      <h1 className="text-3xl font-bold mb-4 dark:text-white">家人协作</h1>

      {/* Health Overview */}
      <Card className="mb-6 border-2 border-teal-200 dark:border-teal-800">
        <CardHeader>
          <CardTitle className="text-2xl">健康概览</CardTitle>
          <CardDescription className="text-lg">家人可查看的健康数据</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="glucose" className="w-full">
            <TabsList className="w-full grid grid-cols-2 h-14 text-lg">
              <TabsTrigger value="glucose" className="text-lg">
                血糖记录
              </TabsTrigger>
              <TabsTrigger value="medication" className="text-lg">
                用药记录
              </TabsTrigger>
            </TabsList>
            <TabsContent value="glucose" className="mt-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-semibold dark:text-white">血糖趋势</h3>
                <Badge variant="outline" className="text-base">
                  <TrendingUp className="mr-1 h-4 w-4" />
                  波动
                </Badge>
              </div>
              <ScrollArea className="h-[200px]">
                <div className="space-y-3">
                  {glucoseReadings.map((reading, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="text-lg dark:text-gray-300">{reading.time}</span>
                      <div className="flex items-center">
                        <span
                          className={`text-lg font-bold ${
                            reading.status === "high"
                              ? "text-red-500 dark:text-red-400"
                              : reading.status === "elevated"
                                ? "text-yellow-500 dark:text-yellow-400"
                                : "text-green-500 dark:text-green-400"
                          }`}
                        >
                          {reading.value} mmol/L
                        </span>
                        <div
                          className={`ml-2 w-3 h-3 rounded-full ${
                            reading.status === "high"
                              ? "bg-red-500"
                              : reading.status === "elevated"
                                ? "bg-yellow-500"
                                : "bg-green-500"
                          }`}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>
            <TabsContent value="medication" className="mt-4">
              <h3 className="text-xl font-semibold mb-4 dark:text-white">用药记录</h3>
              <ScrollArea className="h-[200px]">
                <div className="space-y-3">
                  {medicationAdherence.map((day, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="text-lg dark:text-gray-300">{day.date}</span>
                      <div className="flex space-x-4">
                        <Badge
                          variant={day.morning ? "default" : "outline"}
                          className={`text-base ${day.morning ? "bg-green-500" : "text-gray-500"}`}
                        >
                          早上
                        </Badge>
                        <Badge
                          variant={day.noon ? "default" : "outline"}
                          className={`text-base ${day.noon ? "bg-green-500" : "text-gray-500"}`}
                        >
                          中午
                        </Badge>
                        <Badge
                          variant={day.evening ? "default" : "outline"}
                          className={`text-base ${day.evening ? "bg-green-500" : "text-gray-500"}`}
                        >
                          晚上
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Family Members */}
      <div className="mb-4 flex justify-between items-center">
        <h2 className="text-2xl font-bold dark:text-white">家人成员</h2>
        <Button className="text-lg bg-teal-500 hover:bg-teal-600">
          <UserPlus className="mr-2 h-5 w-5" />
          添加家人
        </Button>
      </div>

      <div className="space-y-4">
        {familyMembers.map((member) => (
          <Card key={member.id} className="border-2 border-gray-200 dark:border-gray-700">
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center mb-2">
                    <h3 className="text-xl font-bold dark:text-white">{member.name}</h3>
                    <Badge className="ml-2 text-base">{member.relation}</Badge>
                  </div>
                  <div className="text-lg text-gray-500 dark:text-gray-400 mb-2">上次活跃: {member.lastActive}</div>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {member.permissions.map((permission, index) => (
                      <Badge key={index} variant="outline" className="text-base">
                        {permission === "查看血糖" && <Activity className="mr-1 h-4 w-4" />}
                        {permission === "查看用药" && <Bell className="mr-1 h-4 w-4" />}
                        {permission === "查看录音" && <Eye className="mr-1 h-4 w-4" />}
                        {permission === "紧急联系人" && <ShieldAlert className="mr-1 h-4 w-4" />}
                        {permission}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="icon" className="h-12 w-12">
                    <Phone className="h-6 w-6 text-teal-500 dark:text-teal-400" />
                  </Button>
                  <Button variant="outline" size="icon" className="h-12 w-12">
                    <MessageSquare className="h-6 w-6 text-teal-500 dark:text-teal-400" />
                  </Button>
                </div>
              </div>
              <div className="flex justify-end mt-4">
                <Button
                  variant="ghost"
                  className="text-lg text-teal-500 dark:text-teal-400"
                  onClick={() => handlePermissionClick(member.name)}
                >
                  <Shield className="mr-2 h-5 w-5" />
                  管理权限
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Permission Dialog */}
      <Dialog open={showPermissionDialog} onOpenChange={setShowPermissionDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl">权限设置</DialogTitle>
            <DialogDescription className="text-lg">
              {selectedMember ? `设置 ${selectedMember} 可以查看的信息` : "设置家人可以查看的信息"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Activity className="h-5 w-5 text-teal-500 dark:text-teal-400" />
                <Label htmlFor="glucose" className="text-xl">
                  查看血糖记录
                </Label>
              </div>
              <Switch id="glucose" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Bell className="h-5 w-5 text-teal-500 dark:text-teal-400" />
                <Label htmlFor="medication" className="text-xl">
                  查看用药记录
                </Label>
              </div>
              <Switch id="medication" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Eye className="h-5 w-5 text-teal-500 dark:text-teal-400" />
                <Label htmlFor="recordings" className="text-xl">
                  查看医生问诊录音
                </Label>
              </div>
              <Switch id="recordings" />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <ShieldAlert className="h-5 w-5 text-teal-500 dark:text-teal-400" />
                <Label htmlFor="emergency" className="text-xl">
                  紧急联系人
                </Label>
              </div>
              <Switch id="emergency" defaultChecked />
            </div>
          </div>
          <DialogFooter>
            <Button className="text-lg bg-teal-500 hover:bg-teal-600 w-full">保存设置</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
