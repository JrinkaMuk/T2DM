"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Mic, MicOff, AlertTriangle, Clock, Calendar, Play, Trash2 } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"

export function HomeScreen() {
  const [isRecording, setIsRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [showAlert, setShowAlert] = useState(true)
  const [showSavedDialog, setShowSavedDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [selectedRecording, setSelectedRecording] = useState<number | null>(null)

  // Mock data for recent recordings
  const recordings = [
    {
      id: 1,
      doctor: "张医生",
      date: "2023-05-15",
      time: "14:30",
      duration: "12:45",
      notes: "血糖控制情况讨论，调整胰岛素用量",
    },
    {
      id: 2,
      doctor: "李医生",
      date: "2023-05-01",
      time: "10:15",
      duration: "08:22",
      notes: "足部检查，讨论饮食计划",
    },
    {
      id: 3,
      doctor: "王医生",
      date: "2023-04-20",
      time: "16:00",
      duration: "15:10",
      notes: "季度复查，血压偏高，需要调整药物",
    },
  ]

  useEffect(() => {
    let interval: NodeJS.Timeout

    if (isRecording) {
      interval = setInterval(() => {
        setRecordingTime((prevTime) => prevTime + 1)
      }, 1000)
    } else if (!isRecording && recordingTime !== 0) {
      clearInterval(interval)
    }

    return () => clearInterval(interval)
  }, [isRecording, recordingTime])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const handleRecordToggle = () => {
    if (!isRecording) {
      // Start recording
      setIsRecording(true)
      setRecordingTime(0)
    } else {
      // Stop recording and show saved dialog
      setIsRecording(false)
      setShowSavedDialog(true)

      // Simulate haptic feedback
      if (navigator.vibrate) {
        navigator.vibrate(150)
      }

      // Auto-close dialog after 2 seconds
      setTimeout(() => {
        setShowSavedDialog(false)
      }, 2000)
    }
  }

  const handleDeleteRecording = (id: number) => {
    setSelectedRecording(id)
    setShowDeleteDialog(true)
  }

  return (
    <div className="p-4 pb-20">
      {/* Alert for high blood glucose */}
      {showAlert && (
        <Alert className="mb-6 bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-800">
          <AlertTriangle className="h-6 w-6 text-red-600 dark:text-red-400" />
          <AlertTitle className="text-xl font-bold text-red-600 dark:text-red-400">血糖过高警告!</AlertTitle>
          <AlertDescription className="text-lg text-red-600 dark:text-red-400">
            您的血糖读数为 11.2 mmol/L，高于正常范围。请按照医嘱服用药物并多喝水。
          </AlertDescription>
          <Button
            variant="outline"
            className="mt-2 text-lg border-red-200 text-red-600 hover:bg-red-100 dark:border-red-800 dark:text-red-400 dark:hover:bg-red-900/50"
            onClick={() => setShowAlert(false)}
          >
            我知道了
          </Button>
        </Alert>
      )}

      {/* Today's Overview */}
      <h1 className="text-3xl font-bold mb-4 dark:text-white">今日概览</h1>
      <div className="grid grid-cols-2 gap-4 mb-6">
        <Card className="border-2 border-teal-200 dark:border-teal-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">血糖</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              11.2 <span className="text-xl font-normal">mmol/L</span>
            </div>
            <p className="text-lg text-red-500 dark:text-red-400">高于正常范围</p>
          </CardContent>
        </Card>
        <Card className="border-2 border-teal-200 dark:border-teal-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">用药提醒</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">2/3</div>
            <p className="text-lg text-gray-500 dark:text-gray-400">今日已服用</p>
          </CardContent>
        </Card>
      </div>

      {/* Recording Section */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4 dark:text-white">医生问诊录音</h2>
        <div className="flex flex-col items-center justify-center bg-white dark:bg-gray-800 rounded-xl p-6 shadow-md">
          <div className="mb-4 text-xl">
            {isRecording ? (
              <div className="flex items-center text-red-500 dark:text-red-400">
                <span className="animate-pulse mr-2">●</span> 正在录音 {formatTime(recordingTime)}
              </div>
            ) : (
              <div className="text-gray-500 dark:text-gray-400">点击下方按钮开始录音</div>
            )}
          </div>
          <button
            onClick={handleRecordToggle}
            className={`w-20 h-20 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 ${
              isRecording ? "bg-red-500 hover:bg-red-600 animate-pulse" : "bg-teal-500 hover:bg-teal-600"
            }`}
          >
            {isRecording ? <MicOff className="h-10 w-10 text-white" /> : <Mic className="h-10 w-10 text-white" />}
          </button>
          <div className="mt-4 text-lg text-gray-500 dark:text-gray-400">
            {isRecording ? "点击停止录音" : "点击开始录音"}
          </div>
        </div>
      </div>

      {/* Recent Recordings */}
      <h2 className="text-2xl font-bold mb-4 dark:text-white">近期录音</h2>
      <ScrollArea className="h-[400px] rounded-md">
        <div className="space-y-4">
          {recordings.map((recording) => (
            <Card key={recording.id} className="border-2 border-gray-200 dark:border-gray-700">
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center">
                    <div className="text-xl font-bold dark:text-white">{recording.doctor}</div>
                    <Badge variant="outline" className="ml-2 text-base">
                      {recording.duration}
                    </Badge>
                  </div>
                  <div className="flex">
                    <Button variant="ghost" size="icon" className="h-10 w-10">
                      <Play className="h-6 w-6 text-teal-500 dark:text-teal-400" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-10 w-10 text-red-500 dark:text-red-400"
                      onClick={() => handleDeleteRecording(recording.id)}
                    >
                      <Trash2 className="h-6 w-6" />
                    </Button>
                  </div>
                </div>
                <div className="flex items-center text-lg text-gray-500 dark:text-gray-400 mb-2">
                  <Calendar className="h-5 w-5 mr-2" />
                  {recording.date}
                  <Clock className="h-5 w-5 ml-4 mr-2" />
                  {recording.time}
                </div>
                <p className="text-lg dark:text-gray-300">{recording.notes}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </ScrollArea>

      {/* Recording Saved Dialog */}
      <Dialog open={showSavedDialog} onOpenChange={setShowSavedDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl text-center">录音已保存!</DialogTitle>
          </DialogHeader>
          <div className="flex justify-center my-4">
            <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
              <Mic className="h-8 w-8 text-green-600 dark:text-green-400" />
            </div>
          </div>
          <DialogDescription className="text-center text-xl">您的医生问诊录音已成功保存</DialogDescription>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl">确认删除录音?</DialogTitle>
          </DialogHeader>
          <DialogDescription className="text-lg">此操作无法撤销，录音将被永久删除。</DialogDescription>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" className="text-lg flex-1" onClick={() => setShowDeleteDialog(false)}>
              取消
            </Button>
            <Button
              variant="destructive"
              className="text-lg flex-1"
              onClick={() => {
                // Handle delete logic here
                setShowDeleteDialog(false)
              }}
            >
              确认删除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
