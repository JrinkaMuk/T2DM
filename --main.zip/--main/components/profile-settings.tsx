"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  User,
  Settings,
  Volume2,
  Bell,
  Moon,
  SunMedium,
  LogOut,
  ChevronRight,
  Smartphone,
  Eye,
  HelpCircle,
  FileText,
} from "lucide-react"

export function ProfileSettings() {
  const [fontSize, setFontSize] = useState(20)
  const [voiceGuidance, setVoiceGuidance] = useState(true)
  const [darkMode, setDarkMode] = useState(false)
  const [notifications, setNotifications] = useState(true)

  return (
    <div className="p-4 pb-20">
      <h1 className="text-3xl font-bold mb-4 dark:text-white">个人设置</h1>

      {/* User Profile */}
      <Card className="mb-6 border-2 border-teal-200 dark:border-teal-800">
        <CardContent className="p-6">
          <div className="flex items-center">
            <div className="w-20 h-20 bg-teal-100 dark:bg-teal-800 rounded-full flex items-center justify-center">
              <User className="h-10 w-10 text-teal-500 dark:text-teal-400" />
            </div>
            <div className="ml-4">
              <h2 className="text-2xl font-bold dark:text-white">张大明</h2>
              <p className="text-lg text-gray-500 dark:text-gray-400">68岁 | 2型糖尿病患者</p>
            </div>
          </div>
          <Button className="w-full mt-4 text-lg bg-teal-500 hover:bg-teal-600">编辑个人信息</Button>
        </CardContent>
      </Card>

      {/* Accessibility Settings */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center">
            <Eye className="mr-2 h-6 w-6 text-teal-500 dark:text-teal-400" />
            无障碍设置
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label htmlFor="font-size" className="text-xl">
                文字大小
              </Label>
              <span className="text-lg font-medium">{fontSize}pt</span>
            </div>
            <Slider
              id="font-size"
              min={16}
              max={32}
              step={1}
              value={[fontSize]}
              onValueChange={(value) => setFontSize(value[0])}
              className="h-6"
            />
            <div className="flex mt-2">
              <span className="text-base">A</span>
              <span className="flex-1"></span>
              <span className="text-2xl">A</span>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Volume2 className="h-6 w-6 text-teal-500 dark:text-teal-400" />
              <Label htmlFor="voice-guidance" className="text-xl">
                语音引导
              </Label>
            </div>
            <Switch id="voice-guidance" checked={voiceGuidance} onCheckedChange={setVoiceGuidance} />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {darkMode ? (
                <Moon className="h-6 w-6 text-teal-500 dark:text-teal-400" />
              ) : (
                <SunMedium className="h-6 w-6 text-teal-500 dark:text-teal-400" />
              )}
              <Label htmlFor="dark-mode" className="text-xl">
                深色模式
              </Label>
            </div>
            <Switch id="dark-mode" checked={darkMode} onCheckedChange={setDarkMode} />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Bell className="h-6 w-6 text-teal-500 dark:text-teal-400" />
              <Label htmlFor="notifications" className="text-xl">
                通知提醒
              </Label>
            </div>
            <Switch id="notifications" checked={notifications} onCheckedChange={setNotifications} />
          </div>
        </CardContent>
      </Card>

      {/* Other Settings */}
      <ScrollArea className="h-[300px]">
        <div className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <Button variant="ghost" className="w-full justify-between p-4 text-xl h-auto">
                <div className="flex items-center">
                  <Smartphone className="mr-3 h-6 w-6 text-teal-500 dark:text-teal-400" />
                  设备管理
                </div>
                <ChevronRight className="h-6 w-6" />
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-0">
              <Button variant="ghost" className="w-full justify-between p-4 text-xl h-auto">
                <div className="flex items-center">
                  <FileText className="mr-3 h-6 w-6 text-teal-500 dark:text-teal-400" />
                  隐私政策
                </div>
                <ChevronRight className="h-6 w-6" />
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-0">
              <Button variant="ghost" className="w-full justify-between p-4 text-xl h-auto">
                <div className="flex items-center">
                  <HelpCircle className="mr-3 h-6 w-6 text-teal-500 dark:text-teal-400" />
                  帮助中心
                </div>
                <ChevronRight className="h-6 w-6" />
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-0">
              <Button variant="ghost" className="w-full justify-between p-4 text-xl h-auto">
                <div className="flex items-center">
                  <Settings className="mr-3 h-6 w-6 text-teal-500 dark:text-teal-400" />
                  高级设置
                </div>
                <ChevronRight className="h-6 w-6" />
              </Button>
            </CardContent>
          </Card>

          <Button variant="destructive" className="w-full text-xl mt-6 mb-10">
            <LogOut className="mr-2 h-6 w-6" />
            退出登录
          </Button>
        </div>
      </ScrollArea>
    </div>
  )
}
