"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Loader2, FileText, Calendar } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { Checkbox } from "@/components/ui/checkbox"
import { ScrollArea } from "@/components/ui/scroll-area"
import { clientDataService } from "@/lib/data-service"

interface ReportDialogProps {
  onReportCreated?: () => void
}

export function ReportDialog({ onReportCreated }: ReportDialogProps) {
  const [open, setOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [title, setTitle] = useState("")
  const [reportType, setReportType] = useState("月度报告")
  const [diagnosisRecords, setDiagnosisRecords] = useState<any[]>([])
  const [selectedDiagnoses, setSelectedDiagnoses] = useState<string[]>([])
  const [dateRange, setDateRange] = useState<{ start: string; end: string }>({
    start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0], // 30天前
    end: new Date().toISOString().split("T")[0], // 今天
  })
  const [isLoadingRecords, setIsLoadingRecords] = useState(false)
  const { user } = useAuth()
  const { toast } = useToast()
  const router = useRouter()

  // 获取用户的诊断记录
  useEffect(() => {
    if (open && user) {
      fetchDiagnosisRecords()
    }
  }, [open, user])

  const fetchDiagnosisRecords = async () => {
    if (!user) return

    setIsLoadingRecords(true)
    try {
      const records = await clientDataService.getUserDiagnosisRecords(user.id)
      setDiagnosisRecords(records || [])
    } catch (error) {
      console.error("Error fetching diagnosis records:", error)
      toast({
        title: "获取诊断记录失败",
        description: "请稍后再试",
        variant: "destructive",
      })
    } finally {
      setIsLoadingRecords(false)
    }
  }

  const handleDiagnosisToggle = (diagnosisId: string) => {
    setSelectedDiagnoses((prev) => {
      if (prev.includes(diagnosisId)) {
        return prev.filter((id) => id !== diagnosisId)
      } else {
        return [...prev, diagnosisId]
      }
    })
  }

  const resetForm = () => {
    setTitle("")
    setReportType("月度报告")
    setSelectedDiagnoses([])
    setDateRange({
      start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      end: new Date().toISOString().split("T")[0],
    })
    setUploadSuccess(false)
    setReportId(null)
  }

  const [uploadSuccess, setUploadSuccess] = useState(false)
  const [reportId, setReportId] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!title || !reportType) {
      toast({
        title: "请填写所有必填字段",
        variant: "destructive",
      })
      return
    }

    if (!user) {
      toast({
        title: "请先登录",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch("/api/generate-report", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: user.id,
          title,
          reportType,
          diagnosisIds: selectedDiagnoses.length > 0 ? selectedDiagnoses : undefined,
          dateRange,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "生成报告失败")
      }

      const data = await response.json()
      console.log("Report created:", data) // 添加日志以便调试

      toast({
        title: "报告生成成功",
        description: "您的健康报告已成功生成",
      })

      setUploadSuccess(true)
      setReportId(data.reportId)

      // 调用回调函数刷新报告列表
      if (onReportCreated) {
        onReportCreated()
      }
    } catch (error) {
      console.error("Report generation error:", error)
      toast({
        title: "生成报告失败",
        description: error instanceof Error ? error.message : "请稍后再试",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleClose = () => {
    setOpen(false)
    resetForm()
  }

  const navigateToReport = () => {
    if (reportId) {
      router.push(`/dashboard/reports/${reportId}`)
    }
    setOpen(false)
    resetForm()
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(newOpen) => {
        setOpen(newOpen)
        if (!newOpen) resetForm()
      }}
    >
      <DialogTrigger asChild>
        <Button className="bg-teal-500 hover:bg-teal-600">
          <FileText className="mr-2 h-4 w-4" />
          生成健康报告
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        {!uploadSuccess ? (
          <>
            <DialogHeader>
              <DialogTitle>生成健康报告</DialogTitle>
              <DialogDescription>系统将根据您的诊断记录和健康对话，生成一份个性化的健康报告</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="title" className="text-right">
                    报告标题
                  </Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="例如：2023年4月健康报告"
                    className="col-span-3"
                    required
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="report-type" className="text-right">
                    报告类型
                  </Label>
                  <Select value={reportType} onValueChange={setReportType}>
                    <SelectTrigger id="report-type" className="col-span-3">
                      <SelectValue placeholder="选择报告类型" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="月度报告">月度报告</SelectItem>
                      <SelectItem value="季度报告">季度报告</SelectItem>
                      <SelectItem value="年度报告">年度报告</SelectItem>
                      <SelectItem value="专项报告">专项报告</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-4 items-center gap-4">
                  <Label className="text-right">日期范围</Label>
                  <div className="col-span-3 flex items-center gap-2">
                    <div className="flex items-center">
                      <Label htmlFor="date-start" className="mr-2 whitespace-nowrap">
                        从:
                      </Label>
                      <Input
                        id="date-start"
                        type="date"
                        value={dateRange.start}
                        onChange={(e) => setDateRange((prev) => ({ ...prev, start: e.target.value }))}
                        className="w-auto"
                      />
                    </div>
                    <div className="flex items-center">
                      <Label htmlFor="date-end" className="mx-2 whitespace-nowrap">
                        至:
                      </Label>
                      <Input
                        id="date-end"
                        type="date"
                        value={dateRange.end}
                        onChange={(e) => setDateRange((prev) => ({ ...prev, end: e.target.value }))}
                        className="w-auto"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-4 items-start gap-4">
                  <Label className="text-right pt-2">选择诊断记录</Label>
                  <div className="col-span-3 border rounded-md p-2">
                    {isLoadingRecords ? (
                      <div className="flex justify-center py-4">
                        <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
                      </div>
                    ) : diagnosisRecords.length > 0 ? (
                      <ScrollArea className="h-[200px] pr-4">
                        <div className="space-y-2">
                          {diagnosisRecords.map((record) => (
                            <div key={record.id} className="flex items-start space-x-2">
                              <Checkbox
                                id={`diagnosis-${record.id}`}
                                checked={selectedDiagnoses.includes(record.id)}
                                onCheckedChange={() => handleDiagnosisToggle(record.id)}
                              />
                              <div className="grid gap-1.5 leading-none">
                                <Label
                                  htmlFor={`diagnosis-${record.id}`}
                                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center"
                                >
                                  <Calendar className="h-3 w-3 mr-1 text-muted-foreground" />
                                  {record.date}
                                </Label>
                                <p className="text-xs text-muted-foreground line-clamp-1">{record.diagnosis}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    ) : (
                      <p className="text-center py-4 text-sm text-muted-foreground">没有找到诊断记录</p>
                    )}
                    <p className="text-xs text-muted-foreground mt-2">
                      {selectedDiagnoses.length > 0
                        ? `已选择 ${selectedDiagnoses.length} 条诊断记录`
                        : "不选择则使用所有诊断记录"}
                    </p>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={handleClose} disabled={isLoading}>
                  取消
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      生成中...
                    </>
                  ) : (
                    "生成报告"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center text-green-600">
                <FileText className="mr-2 h-5 w-5" />
                报告生成成功
              </DialogTitle>
              <DialogDescription>
                您的健康报告已成功生成。报告包含了您的诊断记录和健康对话的分析结果。
              </DialogDescription>
            </DialogHeader>
            <div className="py-6">
              <div className="rounded-lg bg-green-50 dark:bg-green-900/20 p-4 text-sm">
                <p className="font-medium text-green-800 dark:text-green-300 mb-2">报告已添加到您的健康档案</p>
                <p className="text-green-700 dark:text-green-400">
                  您现在可以查看此报告，并在下次就诊时提供给医生参考。
                </p>
              </div>
            </div>
            <DialogFooter className="flex flex-col sm:flex-row gap-2">
              <Button variant="outline" onClick={handleClose} className="sm:flex-1">
                返回仪表盘
              </Button>
              <Button onClick={navigateToReport} className="bg-teal-500 hover:bg-teal-600 sm:flex-1">
                <FileText className="mr-2 h-4 w-4" />
                查看报告
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
