"use client"

import type * as React from "react"
import { useState, useEffect, createContext, useContext } from "react"

type Theme = "light" | "dark" | "system"

interface ThemeContextProps {
  theme: Theme
  setTheme: (theme: Theme) => void
}

const ThemeContext = createContext<ThemeContextProps>({
  theme: "system",
  setTheme: () => {},
})

interface ThemeProviderProps extends React.HTMLAttributes<HTMLElement> {
  children: React.ReactNode
  attribute?: string
  defaultTheme?: Theme
  enableSystem?: boolean
  disableTransitionOnChange?: boolean
}

function ThemeProvider({
  children,
  attribute = "class",
  defaultTheme = "light",
  enableSystem = true,
  disableTransitionOnChange = false,
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>(defaultTheme)
  const [mounted, setMounted] = useState(false)

  // 初始化时从localStorage读取主题设置
  useEffect(() => {
    const storedTheme = localStorage.getItem("theme") as Theme | null
    if (storedTheme) {
      setTheme(storedTheme)
    } else if (enableSystem) {
      setTheme("system")
    }
    setMounted(true)
  }, [enableSystem])

  // 应用主题到DOM
  useEffect(() => {
    if (!mounted) return

    const applyTheme = (newTheme: Theme) => {
      const root = window.document.documentElement
      const isDark =
        newTheme === "dark" || (newTheme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches)

      // 移除所有主题类
      root.classList.remove("light", "dark")

      // 添加当前主题类
      root.classList.add(isDark ? "dark" : "light")

      // 设置属性
      root.setAttribute(attribute, isDark ? "dark" : "light")
    }

    // 立即应用主题
    applyTheme(theme)

    // 监听系统主题变化
    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)")
    const handleChange = () => {
      if (theme === "system") {
        applyTheme("system")
      }
    }

    mediaQuery.addEventListener("change", handleChange)
    return () => mediaQuery.removeEventListener("change", handleChange)
  }, [theme, attribute, mounted])

  // 更新主题的函数
  const setThemeValue = (value: Theme) => {
    const newTheme = value
    setTheme(newTheme)

    // 保存到localStorage
    try {
      localStorage.setItem("theme", newTheme)
    } catch (e) {
      console.error("Failed to save theme to localStorage:", e)
    }

    // 立即应用主题变化
    if (mounted) {
      const root = window.document.documentElement
      const isDark =
        newTheme === "dark" || (newTheme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches)

      root.classList.remove("light", "dark")
      root.classList.add(isDark ? "dark" : "light")
      root.setAttribute(attribute, isDark ? "dark" : "light")
    }
  }

  const contextValue = {
    theme,
    setTheme: setThemeValue,
  }

  return <ThemeContext.Provider value={contextValue}>{children}</ThemeContext.Provider>
}

function useTheme() {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider")
  }
  return context
}

export { ThemeProvider, useTheme }
