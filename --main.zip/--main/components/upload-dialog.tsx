"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Upload, Check, MessageSquare } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { useChat } from "@/contexts/chat-context"

interface UploadDialogProps {
  buttonText?: string
  onUploadSuccess?: () => void
}

export function UploadDialog({ buttonText = "上传诊断对话", onUploadSuccess }: UploadDialogProps) {
  const [open, setOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [dialogText, setDialogText] = useState("")
  const [dialogDate, setDialogDate] = useState(new Date().toISOString().split("T")[0])
  const [uploadSuccess, setUploadSuccess] = useState(false)
  const [diagnosisId, setDiagnosisId] = useState<string | null>(null)
  const { user } = useAuth()
  const { toast } = useToast()
  const router = useRouter()
  const { setCurrentSession, updateSession, getSession } = useChat()

  const resetForm = () => {
    setDialogText("")
    setDialogDate(new Date().toISOString().split("T")[0])
    setUploadSuccess(false)
    setDiagnosisId(null)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!dialogText.trim()) {
      toast({
        title: "请输入对话内容",
        variant: "destructive",
      })
      return
    }

    if (!user) {
      toast({
        title: "请先登录",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch("/api/upload-diagnosis", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text: dialogText,
          date: dialogDate,
          userId: user.id,
        }),
      })

      if (!response.ok) {
        throw new Error("上传失败")
      }

      const data = await response.json()

      toast({
        title: "上传成功",
        description: "您的诊断记录已成功上传并分析",
      })

      // 设置上传成功状态和诊断ID
      setUploadSuccess(true)
      setDiagnosisId(data.diagnosisId)

      // 自动分析诊断记录并创建会话
      if (data.diagnosisId) {
        // 创建一个初始消息，表示正在分析
        const initialMessage = {
          id: Date.now().toString(),
          role: "assistant",
          content: "正在分析您的诊断记录，请稍候...",
          timestamp: new Date().toISOString(),
        }

        // 更新会话状态
        // 获取现有会话
        const existingSession = getSession(data.diagnosisId)
        const existingMessages = existingSession?.messages || []

        // 只有在没有现有消息时才设置初始消息
        if (existingMessages.length === 0) {
          updateSession(data.diagnosisId, {
            messages: [initialMessage],
            selectedDiagnosisId: data.diagnosisId,
            diagnosisTerms: [],
          })
        }

        // 调用API分析诊断记录
        try {
          const analysisResponse = await fetch("/api/explain-diagnosis", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ diagnosisId: data.diagnosisId }),
          })

          if (!analysisResponse.ok) {
            throw new Error("分析失败")
          }

          const analysisText = await analysisResponse.text()

          // 更新会话状态，添加分析结果
          const analysisMessage = {
            id: Date.now().toString(),
            role: "assistant",
            content: analysisText,
            timestamp: new Date().toISOString(),
          }

          // 获取当前会话状态
          const currentSession = getSession(data.diagnosisId)
          const currentMessages = currentSession?.messages || []

          // 只有在没有实质性消息或只有初始消息时才更新
          if (currentMessages.length <= 1) {
            updateSession(data.diagnosisId, {
              messages: [analysisMessage],
              selectedDiagnosisId: data.diagnosisId,
            })
          }
        } catch (error) {
          console.error("Error analyzing diagnosis:", error)
          // 如果分析失败，添加错误消息
          const errorMessage = {
            id: Date.now().toString(),
            role: "assistant",
            content: "抱歉，无法分析诊断记录。请稍后再试。",
            timestamp: new Date().toISOString(),
          }

          updateSession(data.diagnosisId, {
            messages: [errorMessage],
            selectedDiagnosisId: data.diagnosisId,
          })
        }
      }

      // 调用成功回调
      if (onUploadSuccess) {
        onUploadSuccess()
      }
    } catch (error) {
      console.error("Upload error:", error)
      toast({
        title: "上传失败",
        description: "请稍后再试",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleClose = () => {
    setOpen(false)
    resetForm()
  }

  const navigateToChat = () => {
    if (diagnosisId) {
      setCurrentSession(diagnosisId)
    }
    setOpen(false)
    resetForm()
    router.push("/dashboard/chat")
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(newOpen) => {
        setOpen(newOpen)
        if (!newOpen) resetForm()
      }}
    >
      <DialogTrigger asChild>
        <Button className="bg-teal-500 hover:bg-teal-600">
          <Upload className="mr-2 h-4 w-4" />
          {buttonText}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[525px]">
        {!uploadSuccess ? (
          <>
            <DialogHeader>
              <DialogTitle>上传诊断对话</DialogTitle>
              <DialogDescription>请粘贴您与医生的对话记录，系统将自动分析并生成诊断总结</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="date" className="text-right">
                    诊断日期
                  </Label>
                  <Input
                    id="date"
                    type="date"
                    value={dialogDate}
                    onChange={(e) => setDialogDate(e.target.value)}
                    className="col-span-3"
                    required
                  />
                </div>
                <div className="grid grid-cols-4 items-start gap-4">
                  <Label htmlFor="dialog" className="text-right pt-2">
                    对话内容
                  </Label>
                  <Textarea
                    id="dialog"
                    value={dialogText}
                    onChange={(e) => setDialogText(e.target.value)}
                    placeholder="请粘贴您与医生的对话内容..."
                    className="col-span-3"
                    rows={10}
                    required
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={handleClose} disabled={isLoading}>
                  取消
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      处理中...
                    </>
                  ) : (
                    "上传并分析"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center text-green-600">
                <Check className="mr-2 h-5 w-5" />
                上传成功
              </DialogTitle>
              <DialogDescription>
                您的诊断对话已成功上传并分析。系统已提取关键信息并识别相关医学术语。
              </DialogDescription>
            </DialogHeader>
            <div className="py-6">
              <div className="rounded-lg bg-green-50 dark:bg-green-900/20 p-4 text-sm">
                <p className="font-medium text-green-800 dark:text-green-300 mb-2">诊断记录已添加到您的健康档案</p>
                <p className="text-green-700 dark:text-green-400">
                  您现在可以在健康对话页面查看此诊断记录，并获取AI助手的详细解释。
                </p>
              </div>
            </div>
            <DialogFooter className="flex flex-col sm:flex-row gap-2">
              <Button variant="outline" onClick={handleClose} className="sm:flex-1">
                返回仪表盘
              </Button>
              <Button onClick={navigateToChat} className="bg-teal-500 hover:bg-teal-600 sm:flex-1">
                <MessageSquare className="mr-2 h-4 w-4" />
                前往健康对话
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
