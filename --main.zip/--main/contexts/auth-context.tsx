"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import { createClientComponentClient } from "@/lib/supabase"
import { useToast } from "@/hooks/use-toast"

interface User {
  id: string
  name: string
}

interface AuthState {
  user: User | null
  isLoading: boolean
  error: string | null
}

interface AuthContextType extends AuthState {
  login: (name: string) => Promise<void>
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isLoading: true,
    error: null,
  })
  const router = useRouter()
  const { toast } = useToast()
  const supabase = createClientComponentClient()

  useEffect(() => {
    // 检查本地存储中的会话信息
    const checkSession = async () => {
      try {
        const storedUser = localStorage.getItem("user")

        if (storedUser) {
          const user = JSON.parse(storedUser)

          // 验证用户是否存在于数据库中
          const { data, error } = await supabase.from("users").select("*").eq("id", user.id).single()

          if (error || !data) {
            localStorage.removeItem("user")
            setAuthState({ user: null, isLoading: false, error: null })
            return
          }

          setAuthState({
            user: { id: data.id, name: data.name },
            isLoading: false,
            error: null,
          })
        } else {
          setAuthState((prev) => ({ ...prev, isLoading: false }))
        }
      } catch (error) {
        console.error("Session check error:", error)
        setAuthState({ user: null, isLoading: false, error: "会话验证失败" })
      }
    }

    checkSession()

    // 设置Supabase实时订阅
    const setupRealtimeSubscriptions = () => {
      // 这里可以添加Supabase实时订阅
    }

    return () => {
      // 清理实时订阅
    }
  }, [supabase])

  const login = async (name: string) => {
    try {
      setAuthState((prev) => ({ ...prev, isLoading: true, error: null }))

      if (!name.trim()) {
        throw new Error("请输入您的姓名")
      }

      // 查找或创建用户
      const { data: existingUser, error: findError } = await supabase
        .from("users")
        .select("*")
        .eq("name", name)
        .maybeSingle()

      let userId

      if (findError) {
        throw findError
      }

      if (existingUser) {
        // 更新最后登录时间
        const { error: updateError } = await supabase
          .from("users")
          .update({ last_login: new Date().toISOString() })
          .eq("id", existingUser.id)

        if (updateError) {
          throw updateError
        }

        userId = existingUser.id
      } else {
        // 创建新用户
        const { data: newUser, error: insertError } = await supabase.from("users").insert({ name }).select().single()

        if (insertError || !newUser) {
          throw insertError || new Error("创建用户失败")
        }

        userId = newUser.id
      }

      const user = { id: userId, name }
      localStorage.setItem("user", JSON.stringify(user))

      setAuthState({
        user,
        isLoading: false,
        error: null,
      })

      toast({
        title: "登录成功",
        description: `欢迎回来，${name}！`,
      })

      router.push("/dashboard")
    } catch (error: any) {
      console.error("Login error:", error)
      setAuthState((prev) => ({
        ...prev,
        isLoading: false,
        error: error.message || "登录失败，请稍后再试",
      }))

      toast({
        title: "登录失败",
        description: error.message || "请稍后再试",
        variant: "destructive",
      })
    }
  }

  const logout = async () => {
    try {
      setAuthState((prev) => ({ ...prev, isLoading: true }))
      localStorage.removeItem("user")
      setAuthState({
        user: null,
        isLoading: false,
        error: null,
      })
      router.push("/login")
    } catch (error: any) {
      console.error("Logout error:", error)
      setAuthState((prev) => ({
        ...prev,
        isLoading: false,
        error: error.message || "登出失败，请稍后再试",
      }))
    }
  }

  return <AuthContext.Provider value={{ ...authState, login, logout }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
