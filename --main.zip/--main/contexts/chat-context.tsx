"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { Message } from "@/types/health"
import type { MedicalTerm } from "@/types/medical-term"
import { useAuth } from "@/contexts/auth-context"
import { createClientComponentClient } from "@/lib/supabase"

interface ChatSession {
  messages: Message[]
  selectedDiagnosisId: string | null
  diagnosisTerms: MedicalTerm[]
  lastUpdated: number // Timestamp for sorting
}

interface ChatContextType {
  sessions: Record<string, ChatSession>
  currentSession: string | null
  setCurrentSession: (sessionId: string | null) => void
  updateSession: (sessionId: string, sessionData: Partial<ChatSession>) => void
  getSession: (sessionId: string) => ChatSession
  clearSession: (sessionId: string) => void
  getAllSessions: () => [string, ChatSession][]
  isLoadingSessions: boolean
}

const defaultSession: ChatSession = {
  messages: [],
  selectedDiagnosisId: null,
  diagnosisTerms: [],
  lastUpdated: Date.now(),
}

const ChatContext = createContext<ChatContextType | undefined>(undefined)

export function ChatProvider({ children }: { children: ReactNode }) {
  const [sessions, setSessions] = useState<Record<string, ChatSession>>({})
  const [currentSession, setCurrentSession] = useState<string | null>(null)
  const [isLoadingSessions, setIsLoadingSessions] = useState(true)
  const { user } = useAuth()
  const supabase = createClientComponentClient()

  // 从数据库加载会话
  useEffect(() => {
    async function loadSessionsFromDatabase() {
      if (!user) {
        setSessions({})
        setCurrentSession(null)
        setIsLoadingSessions(false)
        return
      }

      setIsLoadingSessions(true)
      try {
        // 1. 获取用户的所有诊断记录
        const { data: diagnosisRecords, error: diagnosisError } = await supabase
          .from("diagnosis_records")
          .select("*")
          .eq("user_id", user.id)
          .order("date", { ascending: false })

        if (diagnosisError) {
          console.error("Error fetching diagnosis records:", diagnosisError)
          throw diagnosisError
        }

        // 2. 为每个诊断记录创建一个会话
        const loadedSessions: Record<string, ChatSession> = {}

        // 如果有诊断记录，则加载每个诊断记录的聊天历史
        if (diagnosisRecords && diagnosisRecords.length > 0) {
          for (const record of diagnosisRecords) {
            // 获取与诊断记录关联的聊天历史
            const { data: chatHistory, error: chatError } = await supabase
              .from("chat_history")
              .select("*")
              .eq("diagnosis_id", record.id)
              .eq("user_id", user.id)
              .order("created_at", { ascending: true })

            if (chatError) {
              console.error(`Error fetching chat history for diagnosis ${record.id}:`, chatError)
              continue
            }

            // 将聊天历史转换为消息格式
            const messages: Message[] =
              chatHistory?.map((entry) => ({
                id: entry.id,
                role: entry.message_role as "user" | "assistant",
                content: entry.message_content,
                timestamp: entry.created_at,
              })) || []

            // 获取与诊断记录关联的医学术语
            const { data: termsData, error: termsError } = await supabase
              .from("diagnosis_terms")
              .select(`
                term_id,
                medical_terms (
                  id,
                  term,
                  explanation,
                  category
                )
              `)
              .eq("diagnosis_id", record.id)

            if (termsError) {
              console.error(`Error fetching terms for diagnosis ${record.id}:`, termsError)
            }

            // 提取医学术语数据
            const terms = termsData?.map((item) => item.medical_terms) || []

            // 创建会话
            loadedSessions[record.id] = {
              messages,
              selectedDiagnosisId: record.id,
              diagnosisTerms: terms,
              lastUpdated: new Date(record.date).getTime(),
            }
          }
        }

        // 3. 设置会话状态
        setSessions(loadedSessions)

        // 4. 如果有会话，则设置当前会话为最新的一个
        if (Object.keys(loadedSessions).length > 0) {
          // 获取最新更新的会话
          const sortedSessions = Object.entries(loadedSessions).sort(([, a], [, b]) => b.lastUpdated - a.lastUpdated)
          setCurrentSession(sortedSessions[0][0])
        }

        console.log("Successfully loaded sessions from database:", loadedSessions)
      } catch (error) {
        console.error("Error loading sessions from database:", error)
      } finally {
        setIsLoadingSessions(false)
      }
    }

    loadSessionsFromDatabase()
  }, [user, supabase])

  // 保存会话到数据库
  const updateSession = async (sessionId: string, sessionData: Partial<ChatSession>) => {
    // 更新本地状态
    setSessions((prev) => {
      const existingSession = prev[sessionId] || { ...defaultSession }
      const updatedSession = {
        ...existingSession,
        ...sessionData,
        lastUpdated: Date.now(),
      }

      return {
        ...prev,
        [sessionId]: updatedSession,
      }
    })

    // 如果有新消息，保存到数据库
    if (user && sessionData.messages && sessionData.messages.length > 0) {
      try {
        // 获取最新的消息
        const latestMessage = sessionData.messages[sessionData.messages.length - 1]

        // 检查消息是否已经存在于数据库中
        const { data: existingMessage } = await supabase
          .from("chat_history")
          .select("id")
          .eq("id", latestMessage.id)
          .maybeSingle()

        // 如果消息不存在，则保存到数据库
        if (!existingMessage) {
          await supabase.from("chat_history").insert({
            id: latestMessage.id,
            user_id: user.id,
            diagnosis_id: sessionData.selectedDiagnosisId || sessionId,
            message_role: latestMessage.role,
            message_content: latestMessage.content,
            created_at: latestMessage.timestamp,
          })
        }
      } catch (error) {
        console.error("Error saving message to database:", error)
      }
    }
  }

  const getSession = (sessionId: string): ChatSession => {
    return sessions[sessionId] || { ...defaultSession }
  }

  const clearSession = async (sessionId: string) => {
    // 更新本地状态
    setSessions((prev) => {
      const newSessions = { ...prev }
      delete newSessions[sessionId]
      return newSessions
    })

    // 如果当前会话是被清除的会话，则设置当前会话为null
    if (currentSession === sessionId) {
      setCurrentSession(null)
    }

    // 从数据库中删除会话相关的聊天记录
    if (user) {
      try {
        await supabase.from("chat_history").delete().eq("diagnosis_id", sessionId).eq("user_id", user.id)
      } catch (error) {
        console.error("Error deleting chat history from database:", error)
      }
    }
  }

  const getAllSessions = (): [string, ChatSession][] => {
    return Object.entries(sessions).sort((a, b) => b[1].lastUpdated - a[1].lastUpdated)
  }

  return (
    <ChatContext.Provider
      value={{
        sessions,
        currentSession,
        setCurrentSession,
        updateSession,
        getSession,
        clearSession,
        getAllSessions,
        isLoadingSessions,
      }}
    >
      {children}
    </ChatContext.Provider>
  )
}

export function useChat() {
  const context = useContext(ChatContext)
  if (context === undefined) {
    throw new Error("useChat must be used within a ChatProvider")
  }
  return context
}
