import { createClientComponentClient } from "@/lib/supabase"
import type { Database } from "@/types/supabase"
import type { Message } from "@/types/health"

// 客户端数据服务
export const clientDataService = {
  // 健康记录相关
  async getUserHealthRecords(userId: string) {
    const supabase = createClientComponentClient()
    const { data, error } = await supabase
      .from("health_records")
      .select("*")
      .eq("user_id", userId)
      .order("date", { ascending: false })

    if (error) throw error
    return data
  },

  async createHealthRecord(record: Database["public"]["Tables"]["health_records"]["Insert"]) {
    const supabase = createClientComponentClient()
    const { data, error } = await supabase.from("health_records").insert(record).select().single()

    if (error) throw error
    return data
  },

  // 对话相关
  async getUserConversations(userId: string) {
    const supabase = createClientComponentClient()
    const { data, error } = await supabase
      .from("conversations")
      .select("*")
      .eq("user_id", userId)
      .order("updated_at", { ascending: false })

    if (error) throw error
    return data
  },

  async createConversation(conversation: Database["public"]["Tables"]["conversations"]["Insert"]) {
    const supabase = createClientComponentClient()
    const { data, error } = await supabase.from("conversations").insert(conversation).select().single()

    if (error) throw error
    return data
  },

  async getConversationMessages(conversationId: string) {
    const supabase = createClientComponentClient()
    const { data, error } = await supabase
      .from("messages")
      .select("*")
      .eq("conversation_id", conversationId)
      .order("timestamp", { ascending: true })

    if (error) throw error
    return data
  },

  async addMessage(message: Database["public"]["Tables"]["messages"]["Insert"]) {
    const supabase = createClientComponentClient()
    const { data, error } = await supabase.from("messages").insert(message).select().single()

    if (error) throw error

    // 更新对话的更新时间
    await supabase
      .from("conversations")
      .update({ updated_at: new Date().toISOString() })
      .eq("id", message.conversation_id)

    return data
  },

  // 聊天历史相关 - 新增
  async saveChatHistory(
    userId: string,
    conversationId: string | null,
    diagnosisId: string | null,
    message: Message,
    isAnalysis = false,
  ) {
    const supabase = createClientComponentClient()

    const chatHistoryEntry = {
      user_id: userId,
      conversation_id: conversationId,
      diagnosis_id: diagnosisId,
      message_content: message.content,
      message_role: message.role,
      analysis: isAnalysis,
    }

    const { data, error } = await supabase.from("chat_history").insert(chatHistoryEntry).select().single()

    if (error) {
      console.error("Error saving chat history:", error)
      throw error
    }

    return data
  },

  async getChatHistoryByDiagnosis(diagnosisId: string) {
    const supabase = createClientComponentClient()
    const { data, error } = await supabase
      .from("chat_history")
      .select("*")
      .eq("diagnosis_id", diagnosisId)
      .order("created_at", { ascending: true })

    if (error) {
      console.error("Error fetching chat history:", error)
      throw error
    }

    return data || []
  },

  async getChatHistoryByConversation(conversationId: string) {
    const supabase = createClientComponentClient()
    const { data, error } = await supabase
      .from("chat_history")
      .select("*")
      .eq("conversation_id", conversationId)
      .order("created_at", { ascending: true })

    if (error) throw error
    return data
  },

  // 诊断记录相关
  async getUserDiagnosisRecords(userId: string) {
    const supabase = createClientComponentClient()
    const { data, error } = await supabase
      .from("diagnosis_records")
      .select("*")
      .eq("user_id", userId)
      .order("date", { ascending: false })

    if (error) throw error
    return data
  },

  // 添加获取单个诊断记录的方法
  async getDiagnosisRecord(diagnosisId: string) {
    const supabase = createClientComponentClient()
    const { data, error } = await supabase
      .from("diagnosis_records")
      .select("*")
      .eq("id", diagnosisId)
      .single()

    if (error) {
      console.error("Error fetching diagnosis record:", error)
      throw error
    }

    return data
  },

  // 医学术语相关
  async getMedicalTerms() {
    const supabase = createClientComponentClient()
    const { data, error } = await supabase.from("medical_terms").select("*")

    if (error) throw error
    return data
  },

  // 健康报告相关 - 新增
  async getUserHealthReports(userId: string) {
    const supabase = createClientComponentClient()
    const { data, error } = await supabase
      .from("health_reports")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })

    if (error) throw error
    return data
  },

  async getHealthReportById(reportId: string) {
    const supabase = createClientComponentClient()
    const { data, error } = await supabase.from("health_reports").select("*").eq("id", reportId).single()

    if (error) throw error
    return data
  },

  // 实时订阅
  subscribeToConversation(conversationId: string, callback: (payload: any) => void) {
    const supabase = createClientComponentClient()

    return supabase
      .channel(`conversation:${conversationId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `conversation_id=eq.${conversationId}`,
        },
        callback,
      )
      .subscribe()
  },
}

// 服务器端数据服务
export const serverDataService = {
  // 这里可以添加需要在服务器端执行的数据操作
  // 例如需要使用服务角色权限的操作
}
