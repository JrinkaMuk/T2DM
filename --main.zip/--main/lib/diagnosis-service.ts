import type { DiagnosisRecord, MedicalTerm } from "@/types/diagnosis"

// 模拟数据库中的诊断记录
const mockDiagnosisRecords: DiagnosisRecord[] = [
  {
    id: "diag-001",
    patientId: "1", // 假设这是当前登录用户的ID
    doctorId: "doc-001",
    date: "2023-11-15",
    symptoms: "患者主诉头痛、眩晕、视物模糊，伴有轻度恶心，症状持续3天。",
    diagnosis: "初步诊断为偏头痛，可能与最近工作压力增大、睡眠不足有关。血压测量显示轻度高血压（145/95mmHg）。",
    treatment: "建议休息，减轻工作压力，规律作息。开具盐酸氟桂利嗪胶囊控制偏头痛症状，硝苯地平缓释片控制血压。",
    medications: ["盐酸氟桂利嗪胶囊", "硝苯地平缓释片"],
    followUp: "两周后复诊，如症状加重请立即就医。",
    notes: "患者需要监测血压，保持记录。建议进行颈椎MRI检查排除其他可能。",
  },
  {
    id: "diag-002",
    patientId: "1",
    doctorId: "doc-002",
    date: "2023-12-05",
    symptoms: "患者反映消化不良，腹部不适，饭后腹胀，持续约一周时间。",
    diagnosis: "诊断为功能性消化不良，胃镜检查显示轻度胃炎。幽门螺杆菌检测阴性。",
    treatment: "建议清淡饮食，少食多餐，避免辛辣刺激食物。开具莫沙必利片改善胃动力，雷贝拉唑钠肠溶片减少胃酸分泌。",
    medications: ["莫沙必利片", "雷贝拉唑钠肠溶片"],
    followUp: "一个月后复诊评估治疗效果。",
    notes: "患者应记录饮食情况和症状变化，以便下次就诊时评估。",
  },
]

// 获取用户的诊断记录
export async function getUserDiagnosisRecords(userId: string): Promise<DiagnosisRecord[]> {
  // 在实际应用中，这里会从数据库获取数据
  return mockDiagnosisRecords.filter((record) => record.patientId === userId)
}

// 获取特定的诊断记录
export async function getDiagnosisRecord(diagnosisId: string): Promise<DiagnosisRecord | null> {
  // 在实际应用中，这里会从数据库获取数据
  const record = mockDiagnosisRecords.find((record) => record.id === diagnosisId)
  return record || null
}

// 模拟医学术语库
export const medicalTerms: MedicalTerm[] = [
  { term: "偏头痛", explanation: "一种常见的神经系统疾病，特征是反复发作的中度至重度头痛，通常伴有恶心和对光声敏感。" },
  { term: "高血压", explanation: "血压持续高于正常水平的状态，通常定义为收缩压≥140mmHg和/或舒张压≥90mmHg。" },
  { term: "盐酸氟桂利嗪胶囊", explanation: "一种钙通道阻滞剂，用于预防和治疗偏头痛、眩晕等症状。" },
  { term: "硝苯地平缓释片", explanation: "一种钙拮抗剂，主要用于治疗高血压和心绞痛。" },
  {
    term: "功能性消化不良",
    explanation: "一种常见的消化系统疾病，表现为上腹部不适、早饱、腹胀等症状，但没有明显的器质性病变。",
  },
  { term: "胃炎", explanation: "胃黏膜的炎症，可由多种因素引起，如感染、药物、酒精等。" },
  { term: "幽门螺杆菌", explanation: "一种生活在胃部的细菌，可引起胃炎、胃溃疡，甚至胃癌。" },
  { term: "莫沙必利片", explanation: "一种促胃肠动力药，用于治疗功能性消化不良等胃肠动力障碍疾病。" },
  { term: "雷贝拉唑钠肠溶片", explanation: "一种质子泵抑制剂，用于减少胃酸分泌，治疗胃食管反流病、消化性溃疡等。" },
  { term: "MRI", explanation: "磁共振成像，一种无辐射的医学成像技术，可提供人体内部的详细图像，特别适合软组织检查。" },
  { term: "血压", explanation: "血液在血管中流动时对血管壁的压力，通常以毫米汞柱(mmHg)为单位，分为收缩压和舒张压。" },
  { term: "胃镜", explanation: "一种医疗检查，医生通过一个带有小摄像头的软管观察食道、胃和十二指肠的内部情况。" },
]

// 获取医学术语解释
export function getMedicalTermExplanation(term: string): string | null {
  const termInfo = medicalTerms.find((t) => t.term === term)
  return termInfo ? termInfo.explanation : null
}

// 从文本中提取可能的医学术语
export function extractMedicalTerms(text: string): string[] {
  return medicalTerms.filter((term) => text.includes(term.term)).map((term) => term.term)
}
