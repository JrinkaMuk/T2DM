import { openai } from "@ai-sdk/openai"
import { streamText } from "ai"
import type { DiagnosisRecord } from "@/types/diagnosis"

export interface ChatMessage {
  role: "user" | "assistant" | "system"
  content: string
}

// 更新 cleanResponseText 函数，处理元数据、换行和粗体格式
const cleanResponseText = (text: string): string => {
  // 移除任何元数据前缀，如 f:{"messageId":"msg-..."}
  text = text.replace(/^f:\{"messageId":"[^"]+"\}\s*/, "")

  // 移除任何字符前缀，如 0:" 或 0:
  text = text.replace(/\d+:"|\d+:/g, "")

  // 移除特定的元数据格式
  text = text.replace(/e:\{finishReason:stop,usage:\{promptTokens:\d+,completionTokens:\d+\},isContinued:false\}/g, "")
  text = text.replace(/d:\{finishReason:stop,usage:\{promptTokens:\d+,completionTokens:\d+\}\}/g, "")

  // 移除任何 JSON 后缀，如 e:{"finishReason":"stop",...}
  text = text.replace(/\s*e:\{[^}]+\}.*$/, "")

  // 移除任何其他 JSON 后缀
  text = text.replace(/\s*d:\{[^}]+\}.*$/, "")

  // 移除 ,isContinued:false} 和额外的 }
  text = text.replace(/,isContinued:false\}/g, "")
  text = text.replace(/\}\s*\}$/g, "")

  // 移除任何剩余的元数据格式
  text = text.replace(/[ed]:\{[^}]*\}/g, "")

  // 移除任何孤立的大括号
  text = text.replace(/\}\s*$/g, "")

  // 处理汉字前的引号问题 - 移除单个字符周围的引号
  text = text.replace(/"([^"]{1})"/g, "$1")

  // 处理词组周围的引号 - 移除词组周围的引号
  text = text.replace(/"([^"]+)"/g, "$1")

  // 移除多余的空格和引号
  text = text.replace(/"\s+"/g, " ")
  text = text.replace(/"\s+/g, " ")
  text = text.replace(/\s+"/g, " ")

  // 移除任何剩余的独立引号
  text = text.replace(/"/g, "")

  // 处理换行符 - 将 \n\n 和 \n 转换为 HTML <br> 标签
  text = text.replace(/\\n\\n/g, "<br><br>")
  text = text.replace(/\\n/g, "<br>")

  // 处理实际的换行符
  text = text.replace(/\n\n/g, "<br><br>")
  text = text.replace(/\n/g, "<br>")

  // 处理粗体文本 - 将 **text** 格式转换为 HTML 粗体标签
  text = text.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")

  // 移除多余的空格
  text = text.replace(/\s{2,}/g, " ").trim()

  return text
}

export async function analyzeMedicalConversation(messages: ChatMessage[]) {
  try {
    const result = await streamText({
      model: openai("gpt-4-turbo"),
      messages: messages.map((msg) => ({
        role: msg.role,
        content: msg.content,
      })),
    })

    // Create a modified result with clean text
    const originalToDataStreamResponse = result.toDataStreamResponse
    result.toDataStreamResponse = function () {
      const originalResponse = originalToDataStreamResponse.call(this)

      // Create a new ReadableStream that will clean the text
      const stream = new ReadableStream({
        async start(controller) {
          try {
            const reader = originalResponse.body?.getReader()
            if (!reader) {
              controller.close()
              return
            }

            while (true) {
              const { done, value } = await reader.read()
              if (done) {
                controller.close()
                break
              }

              const decoder = new TextDecoder()
              const text = decoder.decode(value)
              const cleanedText = cleanResponseText(text)
              const encoder = new TextEncoder()
              controller.enqueue(encoder.encode(cleanedText))
            }
          } catch (error) {
            console.error("Error in stream processing:", error)
            controller.error(error)
          }
        },
      })

      return new Response(stream, {
        headers: originalResponse.headers,
        status: originalResponse.status,
        statusText: originalResponse.statusText,
      })
    }

    return result
  } catch (error) {
    console.error("Error analyzing medical conversation:", error)
    throw error
  }
}

export async function explainDiagnosisRecord(diagnosisRecord: DiagnosisRecord) {
  try {
    const diagnosisText = `
诊断日期: ${diagnosisRecord.date}
症状: ${diagnosisRecord.symptoms}
诊断: ${diagnosisRecord.diagnosis}
治疗方案: ${diagnosisRecord.treatment}
药物: ${diagnosisRecord.medications.join(", ")}
复诊安排: ${diagnosisRecord.followUp}
医生备注: ${diagnosisRecord.notes}
`

    const messages = [
      {
        role: "system" as const,
        content:
          "你是一个医疗解释专家，你的任务是将医学诊断单中的专业术语和内容转换为普通人能够理解的语言。请详细解释诊断单中的医学术语，并提供患者应该了解的关键信息。保持友好、专业的语气，避免使用过于专业的术语，如果必须使用，请提供简明的解释。",
      },
      {
        role: "user" as const,
        content: `请解释以下诊断单内容，使普通患者能够理解：\n\n${diagnosisText}`,
      },
    ]

    const result = await streamText({
      model: openai("gpt-4-turbo"),
      messages,
    })

    // Create a modified result with clean text
    const originalToDataStreamResponse = result.toDataStreamResponse
    result.toDataStreamResponse = function () {
      const originalResponse = originalToDataStreamResponse.call(this)

      // Create a new ReadableStream that will clean the text
      const stream = new ReadableStream({
        async start(controller) {
          try {
            const reader = originalResponse.body?.getReader()
            if (!reader) {
              controller.close()
              return
            }

            while (true) {
              const { done, value } = await reader.read()
              if (done) {
                controller.close()
                break
              }

              const decoder = new TextDecoder()
              const text = decoder.decode(value)
              const cleanedText = cleanResponseText(text)
              const encoder = new TextEncoder()
              controller.enqueue(encoder.encode(cleanedText))
            }
          } catch (error) {
            console.error("Error in stream processing:", error)
            controller.error(error)
          }
        },
      })

      return new Response(stream, {
        headers: originalResponse.headers,
        status: originalResponse.status,
        statusText: originalResponse.statusText,
      })
    }

    return result
  } catch (error) {
    console.error("Error explaining diagnosis record:", error)
    throw error
  }
}

export async function explainMedicalTerms(text: string) {
  try {
    const messages = [
      {
        role: "system" as const,
        content: "你是一个医学术语解释专家。请识别以下文本中的医学术语，并提供简明易懂的解释。",
      },
      {
        role: "user" as const,
        content: text,
      },
    ]

    const result = await streamText({
      model: openai("gpt-4-turbo"),
      messages,
    })

    // Apply the same cleaning to this response
    const originalToDataStreamResponse = result.toDataStreamResponse
    result.toDataStreamResponse = function () {
      const originalResponse = originalToDataStreamResponse.call(this)

      // Create a new ReadableStream that will clean the text
      const stream = new ReadableStream({
        async start(controller) {
          try {
            const reader = originalResponse.body?.getReader()
            if (!reader) {
              controller.close()
              return
            }

            while (true) {
              const { done, value } = await reader.read()
              if (done) {
                controller.close()
                break
              }

              const decoder = new TextDecoder()
              const text = decoder.decode(value)
              const cleanedText = cleanResponseText(text)
              const encoder = new TextEncoder()
              controller.enqueue(encoder.encode(cleanedText))
            }
          } catch (error) {
            console.error("Error in stream processing:", error)
            controller.error(error)
          }
        },
      })

      return new Response(stream, {
        headers: originalResponse.headers,
        status: originalResponse.status,
        statusText: originalResponse.statusText,
      })
    }

    return result
  } catch (error) {
    console.error("Error explaining medical terms:", error)
    throw error
  }
}

export async function explainSingleMedicalTerm(term: string) {
  try {
    const messages = [
      {
        role: "system" as const,
        content: "你是一个医学术语解释专家。请提供以下医学术语的简明易懂的解释，包括其定义、用途和相关信息。",
      },
      {
        role: "user" as const,
        content: `请解释医学术语"${term}"`,
      },
    ]

    const result = await streamText({
      model: openai("gpt-4-turbo"),
      messages,
    })

    // Apply the same cleaning to this response
    const originalToDataStreamResponse = result.toDataStreamResponse
    result.toDataStreamResponse = function () {
      const originalResponse = originalToDataStreamResponse.call(this)

      // Create a new ReadableStream that will clean the text
      const stream = new ReadableStream({
        async start(controller) {
          try {
            const reader = originalResponse.body?.getReader()
            if (!reader) {
              controller.close()
              return
            }

            while (true) {
              const { done, value } = await reader.read()
              if (done) {
                controller.close()
                break
              }

              const decoder = new TextDecoder()
              const text = decoder.decode(value)
              const cleanedText = cleanResponseText(text)
              const encoder = new TextEncoder()
              controller.enqueue(encoder.encode(cleanedText))
            }
          } catch (error) {
            console.error("Error in stream processing:", error)
            controller.error(error)
          }
        },
      })

      return new Response(stream, {
        headers: originalResponse.headers,
        status: originalResponse.status,
        statusText: originalResponse.statusText,
      })
    }

    return result
  } catch (error) {
    console.error("Error explaining medical term:", error)
    throw error
  }
}

export async function evaluateHealthData(dietData: string, exerciseData: string) {
  try {
    const messages = [
      {
        role: "system" as const,
        content: "你是一个健康数据分析专家。请分析以下饮食和运动数据，并提供健康建议。",
      },
      {
        role: "user" as const,
        content: `饮食数据：${dietData}\n\n运动数据：${exerciseData}`,
      },
    ]

    const result = await streamText({
      model: openai("gpt-4-turbo"),
      messages,
    })

    // Apply the same cleaning to this response
    const originalToDataStreamResponse = result.toDataStreamResponse
    result.toDataStreamResponse = function () {
      const originalResponse = originalToDataStreamResponse.call(this)

      // Create a new ReadableStream that will clean the text
      const stream = new ReadableStream({
        async start(controller) {
          try {
            const reader = originalResponse.body?.getReader()
            if (!reader) {
              controller.close()
              return
            }

            while (true) {
              const { done, value } = await reader.read()
              if (done) {
                controller.close()
                break
              }

              const decoder = new TextDecoder()
              const text = decoder.decode(value)
              const cleanedText = cleanResponseText(text)
              const encoder = new TextEncoder()
              controller.enqueue(encoder.encode(cleanedText))
            }
          } catch (error) {
            console.error("Error in stream processing:", error)
            controller.error(error)
          }
        },
      })

      return new Response(stream, {
        headers: originalResponse.headers,
        status: originalResponse.status,
        statusText: originalResponse.statusText,
      })
    }

    return result
  } catch (error) {
    console.error("Error evaluating health data:", error)
    throw error
  }
}

export async function generateMedicalReport(healthData: any, conversations: any) {
  try {
    const messages = [
      {
        role: "system" as const,
        content: "你是一个医疗报告生成专家。请根据以下健康数据和对话记录，生成一份结构化的医疗报告。",
      },
      {
        role: "user" as const,
        content: `健康数据：${JSON.stringify(healthData)}\n\n对话记录：${JSON.stringify(conversations)}`,
      },
    ]

    const result = await streamText({
      model: openai("gpt-4-turbo"),
      messages,
    })

    // Apply the same cleaning to this response
    const originalToDataStreamResponse = result.toDataStreamResponse
    result.toDataStreamResponse = function () {
      const originalResponse = originalToDataStreamResponse.call(this)

      // Create a new ReadableStream that will clean the text
      const stream = new ReadableStream({
        async start(controller) {
          try {
            const reader = originalResponse.body?.getReader()
            if (!reader) {
              controller.close()
              return
            }

            while (true) {
              const { done, value } = await reader.read()
              if (done) {
                controller.close()
                break
              }

              const decoder = new TextDecoder()
              const text = decoder.decode(value)
              const cleanedText = cleanResponseText(text)
              const encoder = new TextEncoder()
              controller.enqueue(encoder.encode(cleanedText))
            }
          } catch (error) {
            console.error("Error in stream processing:", error)
            controller.error(error)
          }
        },
      })

      return new Response(stream, {
        headers: originalResponse.headers,
        status: originalResponse.status,
        statusText: originalResponse.statusText,
      })
    }

    return result
  } catch (error) {
    console.error("Error generating medical report:", error)
    throw error
  }
}
