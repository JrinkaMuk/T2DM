import { createClient } from "@supabase/supabase-js"
import type { Database } from "@/types/supabase"

// 创建单例模式的客户端，避免多次实例化
let supabaseInstance: ReturnType<typeof createClient<Database>> | null = null

// 客户端端Supabase客户端
export const createClientComponentClient = () => {
  if (supabaseInstance) return supabaseInstance

  supabaseInstance = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
  )

  return supabaseInstance
}

// 服务器端Supabase客户端
export const createServerComponentClient = () => {
  return createClient<Database>(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
}
