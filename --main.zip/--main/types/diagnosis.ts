export interface MedicalTerm {
  term: string
  explanation: string
}

export interface DiagnosisRecord {
  id: string
  patientId: string
  doctorId: string
  date: string
  symptoms: string
  diagnosis: string
  treatment: string
  medications: string[]
  followUp: string
  notes: string
}
