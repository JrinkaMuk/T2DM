export interface HealthRecord {
  id: string
  userId: string
  date: string
  diet: string
  exercise: string
  notes: string
  evaluation?: string
  createdAt: string
}

export interface MedicalTerm {
  id: string
  term: string
  explanation: string
  category: string
}

export interface Conversation {
  id: string
  userId: string
  title: string
  messages: Message[]
  createdAt: string
  updatedAt: string
}

export interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: string
}

export interface Report {
  id: string
  userId: string
  title: string
  content: string
  healthRecords: HealthRecord[]
  conversations: Conversation[]
  createdAt: string
}
