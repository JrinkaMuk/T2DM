export interface MedicalTerm {
  id: string
  term: string
  explanation: string
  category: string
}
