export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          name: string
          created_at: string
          last_login: string
        }
        Insert: {
          id?: string
          name: string
          created_at?: string
          last_login?: string
        }
        Update: {
          id?: string
          name?: string
          created_at?: string
          last_login?: string
        }
      }
      health_records: {
        Row: {
          id: string
          user_id: string
          date: string
          diet: string | null
          exercise: string | null
          notes: string | null
          evaluation: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          date: string
          diet?: string | null
          exercise?: string | null
          notes?: string | null
          evaluation?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          date?: string
          diet?: string | null
          exercise?: string | null
          notes?: string | null
          evaluation?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      conversations: {
        Row: {
          id: string
          user_id: string
          title: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          title: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          title?: string
          created_at?: string
          updated_at?: string
        }
      }
      messages: {
        Row: {
          id: string
          conversation_id: string
          role: "user" | "assistant"
          content: string
          timestamp: string
        }
        Insert: {
          id?: string
          conversation_id: string
          role: "user" | "assistant"
          content: string
          timestamp?: string
        }
        Update: {
          id?: string
          conversation_id?: string
          role?: "user" | "assistant"
          content?: string
          timestamp?: string
        }
      }
      medical_terms: {
        Row: {
          id: string
          term: string
          explanation: string
          category: string | null
        }
        Insert: {
          id?: string
          term: string
          explanation: string
          category?: string | null
        }
        Update: {
          id?: string
          term?: string
          explanation?: string
          category?: string | null
        }
      }
      diagnosis_records: {
        Row: {
          id: string
          user_id: string
          doctor_id: string | null
          date: string
          symptoms: string | null
          diagnosis: string
          treatment: string | null
          medications: string[] | null
          follow_up: string | null
          notes: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          doctor_id?: string | null
          date: string
          symptoms?: string | null
          diagnosis: string
          treatment?: string | null
          medications?: string[] | null
          follow_up?: string | null
          notes?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          doctor_id?: string | null
          date?: string
          symptoms?: string | null
          diagnosis?: string
          treatment?: string | null
          medications?: string[] | null
          follow_up?: string | null
          notes?: string | null
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
